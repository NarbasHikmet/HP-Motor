"""Agentic Logic"""
