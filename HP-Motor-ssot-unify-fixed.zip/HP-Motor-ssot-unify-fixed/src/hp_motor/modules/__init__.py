"""
hp_motor.modules

UI-facing / workflow-facing modules that produce *structured* HP artifacts.
These modules should not hard-code player names; they operate on IDs + metadata.
"""