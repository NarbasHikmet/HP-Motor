from __future__ import annotations

"""Player Role Fit (HM3_Individual_NAS seed module)

Goal:
  - Given a minimal event table, produce a *candidate* role fit result.
  - Never hallucinate: if the required columns are missing, abstain.

This module is intentionally conservative; it is a scaffold that will later
bind to the Canon Role Library + Tag Layer.
"""

from dataclasses import dataclass, asdict
from typing import Any, Dict, List

import pandas as pd


@dataclass(frozen=True)
class PlayerRoleFitOutput:
    status: str  # OK / DEGRADED / BLOCKED / ABSTAINED
    player: str
    best_fit_role: str
    confidence: float
    falsifier: str
    notes: List[str]


class PlayerRoleFitEngine:
    def run(self, df: pd.DataFrame) -> Dict[str, Any]:
        notes: List[str] = []

        if df is None or not isinstance(df, pd.DataFrame) or df.empty:
            return asdict(
                PlayerRoleFitOutput(
                    status="ABSTAINED",
                    player="",
                    best_fit_role="",
                    confidence=0.0,
                    falsifier="Input table is empty or invalid.",
                    notes=["Girdi boş/geçersiz; rol uyumu çıkarılamaz."],
                )
            )

        if "player_name" not in df.columns:
            return asdict(
                PlayerRoleFitOutput(
                    status="ABSTAINED",
                    player="",
                    best_fit_role="",
                    confidence=0.0,
                    falsifier="Column 'player_name' is missing.",
                    notes=["player_name kolonu yok; oyuncu bazlı rol uyumu üretmek yasak."],
                )
            )

        # Minimal heuristic: most frequent player in the table is treated as the subject.
        player = str(df["player_name"].mode().iloc[0])

        # Simple event-based cueing (placeholder, will be replaced by Canon-driven scoring):
        # - Many passes -> "Mezzala" candidate
        # - Many shots -> "Inside Forward" candidate
        # - Otherwise -> "Box-to-Box" candidate
        event_col = "event_type" if "event_type" in df.columns else ("type" if "type" in df.columns else None)

        best_role = "Box-to-Box Midfielder"
        confidence = 0.55
        if event_col:
            counts = df[event_col].astype(str).str.lower().value_counts()
            pass_like = sum(counts.get(k, 0) for k in ["pass", "passes"])
            shot_like = sum(counts.get(k, 0) for k in ["shot", "shots"])
            if pass_like >= max(3, shot_like + 2):
                best_role = "Mezzala"
                confidence = 0.70
            elif shot_like >= max(2, pass_like):
                best_role = "Inside Forward"
                confidence = 0.65
        else:
            notes.append("event_type/type kolonu yok; rol çıkarımı yalnızca zayıf ön-kabul ile yapıldı.")
            confidence = 0.40
            best_role = "Candidate: Unknown (needs events)"

        falsifier = (
            "If Canon Role Library scoring disagrees with this heuristic when the required "
            "signals (events+positions+minutes) are provided, this output must be revised."
        )

        status = "OK"
        if confidence < 0.6:
            status = "DEGRADED"
            notes.append("Güven düşük; çıktı aday (candidate) olarak ele alınmalı.")

        return asdict(
            PlayerRoleFitOutput(
                status=status,
                player=player,
                best_fit_role=best_role,
                confidence=float(confidence),
                falsifier=falsifier,
                notes=notes,
            )
        )
