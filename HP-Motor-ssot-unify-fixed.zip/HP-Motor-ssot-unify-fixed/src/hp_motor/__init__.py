"""HP Motor v5.0 Base"""
