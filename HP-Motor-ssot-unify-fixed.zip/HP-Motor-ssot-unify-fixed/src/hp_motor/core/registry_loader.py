from __future__ import annotations

import os
from typing import Any, Dict

import yaml


def _repo_root_from_here() -> str:
    # This file lives under: <repo>/src/hp_motor/core/registry_loader.py
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))


def _candidate_master_registry_paths(repo_root: str) -> list[str]:
    # Preferred SSOT path (declared in the system registry)
    preferred = os.path.join(repo_root, "config", "master_registry.yaml")
    # Backward-compatible path used during early scaffolding
    legacy = os.path.join(repo_root, "src", "hp_motor", "registries", "master_registry.yaml")
    return [preferred, legacy]


def load_master_registry() -> Dict[str, Any]:
    """Load HP-Motor master registry.

    SSOT target:
      - config/master_registry.yaml

    Backward-compat fallback:
      - src/hp_motor/registries/master_registry.yaml

    Raises:
      FileNotFoundError if none of the candidate paths exist.
      ValueError if the YAML cannot be parsed into a dict.
    """
    repo_root = _repo_root_from_here()

    last_err: Exception | None = None
    for path in _candidate_master_registry_paths(repo_root):
        if not os.path.exists(path):
            continue
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
            if not isinstance(data, dict):
                raise ValueError(f"master_registry YAML must be a mapping, got: {type(data)}")
            data.setdefault("_meta", {})
            data["_meta"]["loaded_from"] = os.path.relpath(path, repo_root)
            return data
        except Exception as e:
            last_err = e

    raise FileNotFoundError(
        "master_registry.yaml not found. Expected one of: "
        + ", ".join(os.path.relpath(p, repo_root) for p in _candidate_master_registry_paths(repo_root))
        + (f" (last error: {last_err})" if last_err else "")
    )
