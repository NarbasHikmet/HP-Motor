"""Core Definitions"""
