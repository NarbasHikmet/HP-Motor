"""HP-Motor Canon package.

All ontologies, registries, mappings, and policy documents live under /canon
and are addressed through canon/index.yaml.

Code must consume canon via CanonLoader to prevent double-headed definitions.
"""

from .loader import CanonLoader, CanonIndex

__all__ = ["CanonLoader", "CanonIndex"]
