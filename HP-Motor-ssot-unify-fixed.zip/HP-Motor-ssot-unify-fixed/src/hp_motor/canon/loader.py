from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any, Dict, Optional

import yaml


def _repo_root_from_here() -> str:
    # This file lives under: <repo>/src/hp_motor/canon/loader.py
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))


def _abspath(repo_root: str, rel_or_abs: str) -> str:
    if os.path.isabs(rel_or_abs):
        return rel_or_abs
    return os.path.join(repo_root, rel_or_abs)


def _load_any(path: str) -> Any:
    ext = os.path.splitext(path)[1].lower()
    if ext in {".yaml", ".yml"}:
        with open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    if ext == ".json":
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    # Text fallback (rare, but useful for contracts/policies)
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


@dataclass(frozen=True)
class CanonIndex:
    canon_version: str
    artifacts: Dict[str, str]  # logical_name -> relative path


class CanonLoader:
    """Loads all SSOT canon artifacts via canon/index.yaml.

    Non-negotiable:
      - Only paths declared in canon/index.yaml are treated as SSOT.
      - Code must not embed hard-coded ontology/registry definitions.
    """

    def __init__(self, repo_root: Optional[str] = None) -> None:
        self.repo_root = repo_root or _repo_root_from_here()
        self.index_path = os.path.join(self.repo_root, "canon", "index.yaml")
        self._index: Optional[CanonIndex] = None
        self._cache: Dict[str, Any] = {}

    def index(self) -> CanonIndex:
        if self._index is not None:
            return self._index

        if not os.path.exists(self.index_path):
            raise FileNotFoundError(
                f"canon/index.yaml not found at {self.index_path}. "
                "This file is required to keep SSOT and avoid double-headed definitions."
            )

        with open(self.index_path, "r", encoding="utf-8") as f:
            raw = yaml.safe_load(f) or {}
        if not isinstance(raw, dict):
            raise ValueError("canon/index.yaml must be a mapping")

        canon_version = str(raw.get("canon_version", "unknown"))
        artifacts = raw.get("artifacts") or {}
        if not isinstance(artifacts, dict) or not artifacts:
            raise ValueError("canon/index.yaml must define 'artifacts' mapping")

        # Normalize to strings
        artifacts_norm: Dict[str, str] = {}
        for k, v in artifacts.items():
            artifacts_norm[str(k)] = str(v)

        self._index = CanonIndex(canon_version=canon_version, artifacts=artifacts_norm)
        return self._index

    def path(self, artifact_name: str) -> str:
        idx = self.index()
        if artifact_name not in idx.artifacts:
            raise KeyError(
                f"Unknown canon artifact: {artifact_name}. Known: {sorted(idx.artifacts.keys())}"
            )
        return _abspath(self.repo_root, idx.artifacts[artifact_name])

    def get(self, artifact_name: str) -> Any:
        if artifact_name in self._cache:
            return self._cache[artifact_name]

        p = self.path(artifact_name)
        if not os.path.exists(p):
            raise FileNotFoundError(
                f"Canon artifact '{artifact_name}' points to missing file: {p}"
            )

        data = _load_any(p)
        self._cache[artifact_name] = data
        return data

    def snapshot(self) -> Dict[str, Any]:
        """Load all declared artifacts into a single dict."""
        idx = self.index()
        return {name: self.get(name) for name in idx.artifacts.keys()}
