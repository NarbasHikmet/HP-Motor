from __future__ import annotations

import argparse
from hp_engine.engine import (
    Context, DataRegistry, EntityType, FormatType,
    load_recipes_from_yaml, HPEngine, SquadValidator, ModuleRegistry
)
from hp_engine import modules
from hp_engine.storage import make_match_key, persist_json


def build_engine(recipe_yaml: str) -> HPEngine:
    recipes = load_recipes_from_yaml(recipe_yaml)

    reg = ModuleRegistry()
    reg.register("kadro_guvenlik", modules.kadro_guvenlik)
    reg.register("veri_koprusu_pre", modules.veri_koprusu_pre)
    reg.register("veri_koprusu_post", modules.veri_koprusu_post)
    reg.register("fazparam", modules.fazparam)
    reg.register("energy_pulse", modules.energy_pulse)
    reg.register("energy_leak", modules.energy_leak)
    reg.register("psych_layer", modules.psych_layer)
    reg.register("lkp", modules.lkp)
    reg.register("home_away", modules.home_away)
    reg.register("commentary_renderer", modules.commentary_renderer)
    reg.register("pre_match_matchpack", modules.pre_match_matchpack)

    return HPEngine(recipes=recipes, modules=reg, squad_validator=SquadValidator())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--format", required=True, choices=[f.value for f in FormatType])
    ap.add_argument("--team-a", default="TEAM_A")
    ap.add_argument("--team-b", default="TEAM_B")
    ap.add_argument("--recipe", default="recipes.yaml")
    ap.add_argument("--fitness", action="store_true")
    ap.add_argument("--squad-verified", action="store_true")

    ap.add_argument("--persist", action="store_true", help="persist pre_match output (immutable)")
    ap.add_argument("--persist-dir", default="_persist", help="directory for persisted outputs")

    args = ap.parse_args()

    engine = build_engine(args.recipe)

    data = DataRegistry()
    data.set_availability(
        has_team_fitness=args.fitness,
        has_players_fitness=args.fitness,
        has_match_stats=True,
        has_player_stats=True,
        has_comparison=True,
    )

    ctx = Context(
        entity=EntityType.MATCH,
        format=FormatType(args.format),
        team_a=args.team_a,
        team_b=args.team_b,
        competition="COMP_XXX",
        extra={
            "user_roster_verified": args.squad_verified,
            "match_id": "MATCH_XXXXX",
            "competition_id": "COMP_XXX",
        }
    )

    out = engine.run(ctx, data)

    if args.persist and args.format == "pre_match":
        match_key = make_match_key(ctx.extra["competition_id"], ctx.extra["match_id"])
        persist_json(args.persist_dir, "pre_match_matchpack", match_key, out, immutable=True)
        print(f"persisted -> {args.persist_dir}/pre_match_matchpack/{match_key.replace(':','_')}.json")

    print(out)


if __name__ == "__main__":
    main()
