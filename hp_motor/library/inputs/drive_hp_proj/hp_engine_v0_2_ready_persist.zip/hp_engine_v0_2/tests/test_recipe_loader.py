import os
from hp_engine.engine import load_recipes_from_yaml, FormatType

def test_load_recipes_from_yaml(tmp_path):
    yml = tmp_path / "recipes.yaml"
    yml.write_text("""
version: 0.2
recipes:
  tv_pre:
    name: tv_pre
    bridges: [match_bridge]
    modules: [kadro_guvenlik]
    require_squad_verified: true
""", encoding="utf-8")
    recipes = load_recipes_from_yaml(str(yml))
    assert FormatType.TV_PRE in recipes
    assert recipes[FormatType.TV_PRE].name == "tv_pre"
    assert recipes[FormatType.TV_PRE].modules == ["kadro_guvenlik"]
