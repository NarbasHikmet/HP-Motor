from hp_engine.engine import (
    DataRegistry, Context, EntityType, FormatType, GateEngine, Recipe, BridgeType, Availability
)

def test_fitness_gate_disables_energy_modules_when_missing():
    recipe = Recipe(
        name="tv_pre",
        bridges=[BridgeType.MATCH, BridgeType.ENERGY],
        modules=["fazparam", "energy_pulse", "energy_leak"],
        require_fitness_for=["energy_pulse", "energy_leak"],
        require_squad_verified=False
    )
    av = Availability(has_team_fitness=False, has_players_fitness=False, squad_verified=True)
    decision = GateEngine().decide(recipe, av)
    assert "energy_pulse" not in decision.enabled_modules
    assert "energy_leak" not in decision.enabled_modules
    assert "energy_pulse" in decision.disabled_modules
    assert "energy_leak" in decision.disabled_modules

def test_fitness_gate_keeps_energy_modules_when_available():
    recipe = Recipe(
        name="tv_pre",
        bridges=[BridgeType.MATCH, BridgeType.ENERGY],
        modules=["fazparam", "energy_pulse", "energy_leak"],
        require_fitness_for=["energy_pulse", "energy_leak"],
        require_squad_verified=False
    )
    av = Availability(has_team_fitness=True, has_players_fitness=False, squad_verified=True)
    decision = GateEngine().decide(recipe, av)
    assert "energy_pulse" in decision.enabled_modules
    assert "energy_leak" in decision.enabled_modules
    assert decision.disabled_modules == []

def test_squad_gate_sets_safe_mode_when_not_verified_and_required():
    recipe = Recipe(
        name="tv_pre",
        bridges=[BridgeType.MATCH],
        modules=["kadro_guvenlik", "fazparam"],
        require_squad_verified=True
    )
    av = Availability(squad_verified=False, squad_risk_notes=["risk"])
    decision = GateEngine().decide(recipe, av)
    assert decision.safe_mode is True
    assert "risk" in decision.warnings[0].lower()

def test_squad_gate_safe_mode_even_if_not_required():
    recipe = Recipe(
        name="simulated_commentary",
        bridges=[BridgeType.MATCH],
        modules=["fazparam"],
        require_squad_verified=False
    )
    av = Availability(squad_verified=False, squad_risk_notes=["risk note"])
    decision = GateEngine().decide(recipe, av)
    assert decision.safe_mode is True
