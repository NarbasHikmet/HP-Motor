# HP Engine v0.2 (Config-driven + Gate-driven)

## What this package gives you
- Deterministic **Format → Bridges/Modules/Protocols** correlation via `recipes.yaml`
- **Fitness Gate**: if no fitness data -> Energy modules auto-disable + compensation note
- **Squad Gate (critical)**: if roster not verified -> `safe_mode=True` + warnings; player-level certainty should be avoided

## Install (local)
```bash
pip install -U pyyaml pytest
```

## Run a demo
```bash
python run_demo.py --format simulated_commentary --fitness --squad-verified
python run_demo.py --format tv_pre --fitness
python run_demo.py --format tv_pre
```

## Run tests
```bash
pytest -q
```

## Extend
- Add new formats in `recipes.yaml`
- Register new module implementations in `run_demo.py` (or your app)
- Add more gates (e.g., referee availability gate, opponent data gate)
