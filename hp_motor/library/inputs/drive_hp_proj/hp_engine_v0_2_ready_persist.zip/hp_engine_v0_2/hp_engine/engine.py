from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple
import yaml


# =========================
# Core types
# =========================

class EntityType(str, Enum):
    MATCH = "match"
    TEAM = "team"
    PLAYER = "player"
    TOURNAMENT = "tournament"


class FormatType(str, Enum):
    TV_PRE = "tv_pre"
    TV_POST = "tv_post"
    TOPSUZ_OYUN_PRE = "topsuz_oyun_pre"
    FLOOD_FAZPARAM = "flood_hp_fazparam"
    SCOUTING_PLAYER = "scouting_player"
    SHORT_SUMMARY = "short_summary"
    SIMULATED_COMMENTARY = "simulated_commentary"


class BridgeType(str, Enum):
    MATCH = "match_bridge"
    PLAYER = "player_bridge"
    ENERGY = "energy_bridge"
    PSYCH = "psych_bridge"
    OPP_REF = "opponent_ref_bridge"  # opponent + referee + context


# =========================
# Availability & context
# =========================

@dataclass
class Availability:
    # Data availability flags (set by DataRegistry after ingestion)
    has_team_fitness: bool = False
    has_players_fitness: bool = False
    has_match_stats: bool = False
    has_player_stats: bool = False
    has_comparison: bool = False

    # Squad correctness (set by SquadValidator)
    squad_verified: bool = False
    squad_risk_notes: List[str] = field(default_factory=list)

    def fitness_available(self) -> bool:
        return self.has_team_fitness or self.has_players_fitness


@dataclass
class Context:
    entity: EntityType
    format: FormatType
    team_a: Optional[str] = None
    team_b: Optional[str] = None
    competition: Optional[str] = None
    week: Optional[str] = None
    home_away: Optional[str] = None  # "home" / "away" / None
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class GateDecision:
    enabled_modules: List[str]
    disabled_modules: List[str]
    compensations: List[str]
    warnings: List[str]
    safe_mode: bool  # true when squad isn't verified -> no player-certainty claims


@dataclass
class Recipe:
    name: str
    bridges: List[BridgeType]
    modules: List[str]
    optional_modules: List[str] = field(default_factory=list)
    output_blocks: List[str] = field(default_factory=list)
    require_squad_verified: bool = True
    require_fitness_for: List[str] = field(default_factory=list)


# =========================
# Data registry
# =========================

class DataRegistry:
    """
    Holds loaded datasets & sets availability flags.
    You can implement adapters for Excel, API, etc.
    """
    def __init__(self):
        self.data: Dict[str, Any] = {}
        self.availability = Availability()

    def register(self, key: str, obj: Any):
        self.data[key] = obj

    def set_availability(self, **kwargs):
        for k, v in kwargs.items():
            if hasattr(self.availability, k):
                setattr(self.availability, k, bool(v))

    def get(self, key: str, default=None):
        return self.data.get(key, default)


# =========================
# Validators (critical)
# =========================

class SquadValidator:
    """
    HP-Kadro Güvenlik Protokolü:
    - If roster verified: allow player-level certainty
    - If not verified: safe_mode, forbid certainty claims
    """
    def __init__(self, trusted_rosters: Optional[Dict[str, List[str]]] = None):
        self.trusted_rosters = trusted_rosters or {}

    def verify(self, ctx: Context, reg: DataRegistry) -> Availability:
        av = reg.availability

        # If user provided verified roster in ctx.extra, trust it.
        user_verified = ctx.extra.get("user_roster_verified")
        if user_verified:
            av.squad_verified = True
            return av

        # If we have known rosters for both teams, consider verified.
        if ctx.team_a and ctx.team_b:
            roster_a = self.trusted_rosters.get(ctx.team_a, [])
            roster_b = self.trusted_rosters.get(ctx.team_b, [])
            if roster_a and roster_b:
                av.squad_verified = True
                return av

        # Otherwise: not verified.
        av.squad_verified = False
        if not av.squad_risk_notes:
            av.squad_risk_notes.append(
                "Kadro doğrulanamadı: oyuncu bazlı kesinlik dili kapatılmalı, 11 senaryosu üretimi kısıtlanmalı."
            )
        return av


# =========================
# Gate engine (fitness + squad)
# =========================

class GateEngine:
    def decide(self, recipe: Recipe, av: Availability) -> GateDecision:
        enabled = list(recipe.modules)
        disabled: List[str] = []
        compensations: List[str] = []
        warnings: List[str] = []

        # Squad gate
        safe_mode = False
        if recipe.require_squad_verified and not av.squad_verified:
            safe_mode = True
            warnings.extend(av.squad_risk_notes)
            compensations.append("Oyuncu bazlı kesinlik dili kapatıldı; takım düzeyi anlatım artırıldı.")
        elif not av.squad_verified:
            # recipe allows run but still should be safe
            safe_mode = True
            warnings.extend(av.squad_risk_notes)

        # Fitness gate
        if not av.fitness_available():
            for m in recipe.require_fitness_for:
                if m in enabled:
                    enabled.remove(m)
                    disabled.append(m)
            if disabled:
                compensations.append("Fitness yok: enerji modülleri kapandı; taktik+psiko+tempo-davranış katmanı artırıldı.")

        return GateDecision(
            enabled_modules=enabled,
            disabled_modules=disabled,
            compensations=compensations,
            warnings=warnings,
            safe_mode=safe_mode
        )


# =========================
# Module system
# =========================

ModuleFn = Callable[[Context, DataRegistry, GateDecision], Dict[str, Any]]


class ModuleRegistry:
    def __init__(self):
        self.modules: Dict[str, ModuleFn] = {}

    def register(self, module_id: str, fn: ModuleFn):
        self.modules[module_id] = fn

    def run(self, module_id: str, ctx: Context, reg: DataRegistry, decision: GateDecision) -> Dict[str, Any]:
        fn = self.modules.get(module_id)
        if not fn:
            return {"module": module_id, "status": "missing_module_impl"}
        return fn(ctx, reg, decision)


# =========================
# Output builder
# =========================

class OutputBuilder:
    def build(self, ctx: Context, recipe: Recipe, decision: GateDecision, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        out = {
            "context": {
                "entity": ctx.entity.value,
                "format": ctx.format.value,
                "team_a": ctx.team_a,
                "team_b": ctx.team_b,
                "competition": ctx.competition,
                "week": ctx.week,
                "home_away": ctx.home_away,
            },
            "recipe": recipe.name,
            "warnings": decision.warnings,
            "disabled_modules": decision.disabled_modules,
            "compensations": decision.compensations,
            "safe_mode": decision.safe_mode,
            "results": results,
            "auto_bridge_suggestions": self._suggest(ctx, decision),
        }
        return out

    def _suggest(self, ctx: Context, decision: GateDecision) -> List[str]:
        suggestions = []
        if ctx.format in (FormatType.TV_PRE, FormatType.TOPSUZ_OYUN_PRE):
            suggestions.append("Topsuz Oyun spotu: pres tetikleyicileri + alan karartma (blok/mandal).")
        if "energy_pulse" in decision.enabled_modules:
            suggestions.append("EnergyLeak ile 60–75 penceresinde sızıntı spotu çıkar.")
        if "energy_pulse" not in decision.enabled_modules:
            suggestions.append("Fitness yok: tempo anlatısını faz-ritim + psikodinamik kırılma üzerinden kur.")
        if decision.safe_mode:
            suggestions.append("Kadro teyitsiz: oyuncu bazlı kesin iddia kurma; takım düzeyi konuş.")
        return suggestions


# =========================
# YAML Recipe loader
# =========================

def load_recipes_from_yaml(path: str) -> Dict[FormatType, Recipe]:
    with open(path, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f)

    recipes: Dict[FormatType, Recipe] = {}
    for fmt, cfg in raw["recipes"].items():
        fmt_enum = FormatType(fmt)
        bridges = [BridgeType(b) for b in cfg.get("bridges", [])]
        recipes[fmt_enum] = Recipe(
            name=cfg["name"],
            bridges=bridges,
            modules=cfg.get("modules", []),
            optional_modules=cfg.get("optional_modules", []),
            output_blocks=cfg.get("output_blocks", []),
            require_squad_verified=bool(cfg.get("require_squad_verified", True)),
            require_fitness_for=cfg.get("require_fitness_for", []),
        )
    return recipes


# =========================
# Engine orchestrator
# =========================

class HPEngine:
    def __init__(self, recipes: Dict[FormatType, Recipe], modules: ModuleRegistry, squad_validator: SquadValidator):
        self.recipes = recipes
        self.modules = modules
        self.squad_validator = squad_validator
        self.gates = GateEngine()
        self.builder = OutputBuilder()

    def run(self, ctx: Context, reg: DataRegistry) -> Dict[str, Any]:
        # 1) Validate squad first (critical)
        self.squad_validator.verify(ctx, reg)

        # 2) Select recipe
        recipe = self.recipes[ctx.format]

        # 3) Gate decision (fitness + squad)
        decision = self.gates.decide(recipe, reg.availability)

        # 4) Run enabled modules
        results = []
        for module_id in decision.enabled_modules:
            results.append(self.modules.run(module_id, ctx, reg, decision))

        # 5) Build output
        return self.builder.build(ctx, recipe, decision, results)
