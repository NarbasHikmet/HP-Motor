import json
import os
from typing import Any, Dict


def make_match_key(competition_id: str, match_id: str) -> str:
    return f"{competition_id}:{match_id}"


def persist_json(base_dir: str, persist_key: str, match_key: str, payload: Dict[str, Any], immutable: bool = True) -> str:
    """
    Persist payload to: {base_dir}/{persist_key}/{match_key}.json
    If immutable=True and file exists -> raise.
    """
    dir_path = os.path.join(base_dir, persist_key)
    os.makedirs(dir_path, exist_ok=True)

    safe_name = match_key.replace(":", "_")
    file_path = os.path.join(dir_path, f"{safe_name}.json")

    if immutable and os.path.exists(file_path):
        raise FileExistsError(f"Immutable persist blocked: {file_path} already exists.")

    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

    return file_path


def load_persisted_json(base_dir: str, persist_key: str, match_key: str) -> Dict[str, Any]:
    safe_name = match_key.replace(":", "_")
    file_path = os.path.join(base_dir, persist_key, f"{safe_name}.json")
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)
