from __future__ import annotations
from typing import Dict, Any
from .engine import Context, DataRegistry, GateDecision


def kadro_guvenlik(ctx: Context, reg: DataRegistry, decision: GateDecision) -> Dict[str, Any]:
    return {
        "module": "kadro_guvenlik",
        "status": "ok" if reg.availability.squad_verified else "risk",
        "safe_mode": decision.safe_mode,
        "notes": reg.availability.squad_risk_notes,
    }

def veri_koprusu_pre(ctx: Context, reg: DataRegistry, decision: GateDecision) -> Dict[str, Any]:
    return {"module": "veri_koprusu_pre", "status": "ok", "bridges": ["match", "opponent", "context"]}

def veri_koprusu_post(ctx: Context, reg: DataRegistry, decision: GateDecision) -> Dict[str, Any]:
    return {"module": "veri_koprusu_post", "status": "ok", "bridges": ["match", "player", "context"]}

def fazparam(ctx: Context, reg: DataRegistry, decision: GateDecision) -> Dict[str, Any]:
    return {"module": "fazparam", "status": "ok", "insight": "6 faz iskeleti (takım düzeyi) üretildi."}

def energy_pulse(ctx: Context, reg: DataRegistry, decision: GateDecision) -> Dict[str, Any]:
    if not reg.availability.fitness_available():
        return {"module": "energy_pulse", "status": "skipped_no_fitness"}
    return {
        "module": "energy_pulse",
        "status": "ok",
        "windows": ["0-15", "15-30", "30-45", "45-60", "60-75", "75-90"],
    }

def energy_leak(ctx: Context, reg: DataRegistry, decision: GateDecision) -> Dict[str, Any]:
    if not reg.availability.fitness_available():
        return {"module": "energy_leak", "status": "skipped_no_fitness"}
    return {"module": "energy_leak", "status": "ok", "hotspots": ["60-75 mikro düşüş riski"]}

def psych_layer(ctx: Context, reg: DataRegistry, decision: GateDecision) -> Dict[str, Any]:
    return {"module": "psych_layer", "status": "ok", "insight": "kolektif stres/özgüven frekansı eklendi."}

def lkp(ctx: Context, reg: DataRegistry, decision: GateDecision) -> Dict[str, Any]:
    return {"module": "lkp", "status": "ok", "trend": "sezon içi konum bandı üretildi."}

def home_away(ctx: Context, reg: DataRegistry, decision: GateDecision) -> Dict[str, Any]:
    return {"module": "home_away", "status": "ok", "split": "home/away overlay hazır."}

def commentary_renderer(ctx: Context, reg: DataRegistry, decision: GateDecision) -> Dict[str, Any]:
    # Safe mode: avoid naming specific XI or claiming availability.
    text = "0-15: Erken baskı ve alan sıkıştırma... 15-30: üretim penceresi... 45-60: rakibin direnç periyodu..."
    if decision.safe_mode:
        text += " (Kadro teyitsiz: oyuncu bazlı kesinlik kullanılmadı.)"
    if "energy_pulse" not in decision.enabled_modules:
        text += " (Fitness yok: enerji pencereleri faz-ritim üzerinden anlatıldı.)"
    return {"module": "commentary_renderer", "status": "ok", "text": text}
