\
"""
Streamlit - Clinical Preview Panel (Sprint-0)

Run:
  streamlit run apps/analysis/video_clinical_preview.py
"""

import json
from pathlib import Path

import streamlit as st

from engine.video.title_router import build_video_asset


DEFAULT_LEXICON = "canon/ontology/video_title_lexicon.yaml"
DEFAULT_POLICY  = "canon/policies/video_scope_policy.yaml"

SCOPE_OPTIONS = ["OFFENSIVE", "DEFENSIVE", "TRANSITION", "SET_PIECE", "BODY_ORIENTATION", "POSITIONAL", "UNKNOWN"]


def badge_list(title: str, items: list[str], color: str):
    st.markdown(f"**{title}**")
    if not items:
        st.caption("—")
        return
    # simple colored chips using markdown
    chips = " ".join([f":{color}[`{x}`]" for x in items])
    st.markdown(chips)


def main():
    st.set_page_config(page_title="HP Engine | Video Clinical Preview", layout="wide")
    st.title("HP Engine — Video Clinical Preview (Klinik Önizleme)")

    st.caption("Video, tek başına hüküm kurmaz. Scope dışı iddia üretilmez. Absence ≠ Evidence (Auto-Reject).")

    with st.sidebar:
        st.header("Canon Paths")
        lexicon_path = st.text_input("Lexicon path", DEFAULT_LEXICON)
        policy_path  = st.text_input("Policy path",  DEFAULT_POLICY)

        st.divider()
        st.header("Upload")
        video_file = st.file_uploader("MP4 (optional - for fingerprint later)", type=["mp4", "mov", "m4v"])
        title_raw = st.text_input("Video Title", value="GS vs GAZ | 2026-01-17 | VIDEO | DEFENSIVE | DUELS+TACKLES | RIGHT FLANK")

        st.divider()
        st.header("Manual Override (only if required)")
        manual_scope = st.selectbox("Declared Scope (override)", options=SCOPE_OPTIONS, index=SCOPE_OPTIONS.index("UNKNOWN"))
        manual_tags = st.text_area("Extra Tags (comma-separated)", value="")

    try:
        asset = build_video_asset(title_raw, lexicon_path, policy_path)
    except Exception as e:
        st.error(f"Router error: {e}")
        st.stop()

    # Apply manual override only if needed (no guessing)
    if asset.get("requires_human_tag"):
        st.warning("Low-confidence routing. Manual verification required (Tahmin yok).")
        if manual_scope and manual_scope != "UNKNOWN":
            asset["declared_scope"] = manual_scope
        if manual_tags.strip():
            extra = [t.strip() for t in manual_tags.split(",") if t.strip()]
            asset["tags"] = sorted(set(asset.get("tags", [])) | set(extra))

        # Re-run routing NOT allowed without policy/lexicon; we only allow scope override + tag attach here.
        # The definitive way is: rename the title to include required tokens, or extend lexicon/policy.

    left, right = st.columns([1, 1])

    with left:
        st.subheader("Video Asset Kimlik Kartı")
        st.json(asset)

    with right:
        st.subheader("Klinik Matris")
        st.metric("Declared Scope", asset.get("declared_scope", "UNKNOWN"))
        st.metric("Confidence", asset.get("confidence", 0.0))

        badge_list("Tags", asset.get("tags", []), "blue")
        badge_list("Allowed Dimensions", asset.get("allowed_dimensions", []), "green")
        badge_list("Denied Dimensions", asset.get("denied_dimensions", []), "red")

        st.divider()
        st.subheader("Evidence Gap (Confirmed için)")
        st.write("- Confirmed statüsü için **primary_raw / primary_derived** gerekir.")
        st.write("- Sadece video ile gelen iddialar **candidate** kalır (DOWNGRADED).")
        st.write("- `absence` iddiaları video ile **yasak** (Auto-Reject).")

        st.divider()
        st.subheader("Export")
        export_name = st.text_input("Export filename", value="video_asset.json")
        if st.button("Download Video Asset JSON"):
            st.download_button(
                "Download",
                data=json.dumps(asset, ensure_ascii=False, indent=2),
                file_name=export_name,
                mime="application/json"
            )


if __name__ == "__main__":
    main()
