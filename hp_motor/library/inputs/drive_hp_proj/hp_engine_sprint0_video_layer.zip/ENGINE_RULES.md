# HP Engine — Build Discipline (Kalıcı İnşa Disiplini)

Bu repo **üstüne koyarak** ilerler. Amaç: sürekli sıfırdan inşa etmeden, sözleşmeleri (contracts) koruyarak modüler genişleme.

## Non-negotiables
- **Backward-compatible contracts**: Şema değişiklikleri kırıcı olmayacak; yeni alanlar opsiyonel eklenir.
- **No-evidence, no-claim**: Kanıtsız iddia yok.
- **Absence ≠ Evidence**: Video kliplerden yokluk/yetersizlik iddiası türetilmez.
- **Video cannot confirm alone**: Confirmed için primary_raw / primary_derived şart.
- **Policy-driven**: Lexicon/Policy değişmeden davranış değişmez. Reproducibility esastır.

## Working style
- Yeni bir ihtiyaç: önce Canon policy/lexicon/spec tarafında tanımla, sonra engine’de enforce et.
- Her ekleme: test edilebilir, izlenebilir (provenance + fingerprints), yanlışlanabilir olmalı.
