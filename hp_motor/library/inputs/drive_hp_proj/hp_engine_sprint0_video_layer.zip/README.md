# HP Engine Sprint-0 — Video Asset & Scope Policy Layer (Full Drop-in)

This pack adds (without deleting) the video "legal boundary" layer:
- Lexicon (title -> tags)        : canon/ontology/video_title_lexicon.yaml
- Policy  (tags -> allow/deny)   : canon/policies/video_scope_policy.yaml
- Router (title -> video_asset)  : engine/video/title_router.py
- Gate   (claim vs video_asset)  : engine/validation/scope_gates.py
- UI     (clinical preview)      : apps/analysis/video_clinical_preview.py
- Contract: video_asset schema   : canon/contracts/schemas/video_asset.schema.json
- Example : video_asset example  : canon/contracts/examples/video_asset.example.json

## Run the UI
1) Install deps:
   pip install -r requirements.txt
2) Run:
   streamlit run apps/analysis/video_clinical_preview.py

## Router CLI
python -m engine.video.title_router --title "GS vs GAZ | 2026-01-17 | VIDEO | DEFENSIVE | DUELS+TACKLES | RIGHT FLANK"

## Integration Note
- Video assets should be stored as evidence assets in your run directory (e.g., runs/<run_id>/assets/).
- Claims referencing video must include the video asset dict in the validator input.
