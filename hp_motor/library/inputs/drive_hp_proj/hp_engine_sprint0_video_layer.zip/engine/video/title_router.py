\
"""
HP Engine - Video Title Router (Sprint-0)

Goal:
- Read canon/ontology/video_title_lexicon.yaml
- Read canon/policies/video_scope_policy.yaml
- Convert a VIDEO TITLE into a canonical Video Asset card (VideoAsset)
- Deterministic. No guessing. Low confidence => requires_human_tag=True.

CLI:
  python -m engine.video.title_router --title "GS vs GAZ | 2026-01-17 | VIDEO | DEFENSIVE | DUELS+TACKLES | RIGHT FLANK" \
    --lexicon canon/ontology/video_title_lexicon.yaml \
    --policy  canon/policies/video_scope_policy.yaml
"""

from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml


_TURKISH_FOLD = str.maketrans({
    "ş": "s", "Ş": "s",
    "ğ": "g", "Ğ": "g",
    "ı": "i", "İ": "i",
    "ö": "o", "Ö": "o",
    "ü": "u", "Ü": "u",
    "ç": "c", "Ç": "c",
})


def normalize_title(title: str, cfg: Dict[str, Any]) -> str:
    s = title
    if cfg.get("turkish_char_fold", False):
        s = s.translate(_TURKISH_FOLD)
    if cfg.get("lowercase", True):
        s = s.lower()
    if cfg.get("strip_punctuation", True):
        # keep letters/numbers/space, collapse separators
        s = re.sub(r"[^\w\s]+", " ", s, flags=re.UNICODE)
    if cfg.get("collapse_whitespace", True):
        s = re.sub(r"\s+", " ", s).strip()
    # pad for safer " word " matching
    return f" {s} "


def _keyword_match(normalized_title: str, keyword: str) -> bool:
    kw = keyword.strip().lower()
    if not kw:
        return False

    # If keyword has spaces or hyphen, use substring match.
    if (" " in kw) or ("-" in kw) or ("_" in kw):
        return f" {kw} " in normalized_title or kw in normalized_title

    # Word-boundary-ish match using padding already present.
    return f" {kw} " in normalized_title


def load_yaml(path: str | Path) -> Dict[str, Any]:
    p = Path(path)
    with p.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def extract_tags(title_raw: str, lexicon: Dict[str, Any]) -> Tuple[str, List[str], Dict[str, int]]:
    norm_cfg = lexicon.get("normalization", {}) or {}
    title_norm = normalize_title(title_raw, norm_cfg)

    matched: Dict[str, int] = {}
    for rule in lexicon.get("tags", []):
        tag = rule.get("tag")
        pri = int(rule.get("priority", 0))
        any_of = rule.get("any_of", []) or []
        if not tag or not any_of:
            continue
        for kw in any_of:
            if _keyword_match(title_norm, str(kw)):
                matched[tag] = max(matched.get(tag, 0), pri)
                break

    # stable order: priority desc, then tag name asc
    tags_sorted = sorted(matched.keys(), key=lambda t: (-matched[t], t))
    return title_norm.strip(), tags_sorted, matched


def _match_rule(tags: List[str], when_any: Optional[List[str]] = None, when_all: Optional[List[str]] = None) -> bool:
    s = set(tags)
    if when_all:
        if not set(when_all).issubset(s):
            return False
    if when_any:
        if not (set(when_any) & s):
            return False
    return True


def _apply_focus_overrides(asset: Dict[str, Any], tags: List[str], policy: Dict[str, Any]) -> None:
    for ov in policy.get("focus_overrides", []) or []:
        if _match_rule(tags, ov.get("when_tags_any"), ov.get("when_tags_all")):
            if "declared_scope_override" in ov:
                asset["declared_scope"] = ov["declared_scope_override"]
            if "allowed_scopes_override" in ov:
                asset["allowed_scopes"] = ov["allowed_scopes_override"]
            if "allowed_dimensions_override" in ov:
                asset["allowed_dimensions"] = ov["allowed_dimensions_override"]
            if "narrow_allowed_dimensions" in ov:
                asset["allowed_dimensions"] = ov["narrow_allowed_dimensions"]
            if "denied_dimensions_append" in ov:
                asset.setdefault("denied_dimensions", [])
                asset["denied_dimensions"] = sorted(set(asset["denied_dimensions"]) | set(ov["denied_dimensions_append"]))
            if "confidence_floor_override" in ov:
                asset["_confidence_floor"] = float(ov["confidence_floor_override"])
            if "add_notes" in ov:
                asset.setdefault("notes", "")
                if asset["notes"]:
                    asset["notes"] += " "
                asset["notes"] += str(ov["add_notes"]).strip()


def build_video_asset(title_raw: str, lexicon_path: str, policy_path: str) -> Dict[str, Any]:
    lexicon = load_yaml(lexicon_path)
    policy = load_yaml(policy_path)

    title_normalized, tags, tag_pri = extract_tags(title_raw, lexicon)

    asset: Dict[str, Any] = {
        "asset_type": "video",
        "asset_id": "",  # assigned by caller (UI or pipeline)
        "title_raw": title_raw,
        "title_normalized": title_normalized,
        "tags": tags,
        "declared_scope": "UNKNOWN",
        "allowed_dimensions": [],
        "denied_dimensions": [],
        "allowed_scopes": [],
        "allowed_pattern_families": [],
        "confidence": 0.0,
        "requires_human_tag": True,
        "policy_version": str(policy.get("version", "")),
        "notes": "",
    }

    # Phase selection: first matching rule in phase_rules order
    chosen_rule = None
    for pr in policy.get("phase_rules", []) or []:
        if _match_rule(tags, pr.get("when_tags_any"), None):
            chosen_rule = pr
            break

    if chosen_rule is None:
        # no phase => do not guess
        asset["declared_scope"] = "UNKNOWN"
        asset["allowed_dimensions"] = []
        asset["denied_dimensions"] = []
        asset["allowed_scopes"] = []
        asset["_confidence_floor"] = 0.40
    else:
        asset["declared_scope"] = chosen_rule.get("declared_scope", "UNKNOWN")
        asset["allowed_dimensions"] = list(chosen_rule.get("allowed_dimensions", []) or [])
        asset["denied_dimensions"] = list(chosen_rule.get("denied_dimensions", []) or [])
        asset["allowed_scopes"] = list(chosen_rule.get("allowed_scopes", []) or [])
        asset["allowed_pattern_families"] = list(chosen_rule.get("allowed_pattern_families", []) or [])
        asset["_confidence_floor"] = float(chosen_rule.get("confidence_floor", 0.60))

    # Focus overrides (narrowing, scope overrides, notes)
    _apply_focus_overrides(asset, tags, policy)

    # Deterministic confidence
    floor = float(asset.get("_confidence_floor", 0.60))
    n_focus = sum(1 for t in tags if t.startswith("FOCUS_"))
    n_pattern = sum(1 for t in tags if t.startswith("PATTERN_"))
    n_spatial = sum(1 for t in tags if t.startswith("ZONE_") or t.startswith("CORRIDOR_"))

    conf = floor
    conf += 0.05 * min(5, n_focus)
    conf += 0.03 * min(3, n_pattern)
    conf += 0.02 * min(3, n_spatial)

    # Slight bonus if explicit phase token exists in title
    if any(t.startswith("PHASE_") for t in tags):
        conf += 0.03

    conf = max(0.0, min(1.0, conf))
    asset["confidence"] = round(conf, 3)

    # requires_human_tag = confidence low OR scope unknown
    asset["requires_human_tag"] = (asset["confidence"] < 0.65) or (asset["declared_scope"] == "UNKNOWN")

    # cleanup
    asset.pop("_confidence_floor", None)
    return asset


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--title", required=True, help="Video title to route.")
    ap.add_argument("--lexicon", default="canon/ontology/video_title_lexicon.yaml")
    ap.add_argument("--policy", default="canon/policies/video_scope_policy.yaml")
    ap.add_argument("--asset-id", default="", help="Optional ULID you generated elsewhere.")
    args = ap.parse_args()

    asset = build_video_asset(args.title, args.lexicon, args.policy)
    asset["asset_id"] = args.asset_id or asset.get("asset_id", "")
    print(json.dumps(asset, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
