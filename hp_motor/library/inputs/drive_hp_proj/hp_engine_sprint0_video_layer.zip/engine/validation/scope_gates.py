\
"""
HP Engine - Scope Gates (Sprint-0)

Purpose:
- Enforce "No-Scope, No-Claim" for video evidence
- Enforce "Absence ≠ Evidence" (no absence claims from video clips)
- Enforce "Video cannot confirm alone" (confirmed needs primary evidence)

This module is pure validation. It does not compute metrics.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple


Decision = str  # "APPROVED" | "REJECTED" | "PENDING" | "DOWNGRADED"


@dataclass(frozen=True)
class GateResult:
    decision: Decision
    reason: str


class HPScopeGate:
    def validate_claim(self, claim: Dict, evidence_assets: List[Dict]) -> GateResult:
        """
        Validate a single claim against evidence assets (including video assets).

        claim: a dict matching analysis_claim schema (at least keys: dimension, status, evidence)
        evidence_assets: list of asset dicts (video assets must have asset_type="video")
        """
        video_assets = [a for a in evidence_assets if a.get("asset_type") == "video"]

        claim_type = claim.get("claim_type") or "presence"
        dimension = claim.get("dimension")
        status = claim.get("status")

        # 1) Absence ≠ Evidence (hard rule)
        if claim_type == "absence" and video_assets:
            return GateResult("REJECTED", "Absence claims are prohibited with video evidence (selection bias).")

        # 2) Dimension gating against each video asset (deny list first, then allow list)
        for va in video_assets:
            denied = set(va.get("denied_dimensions", []) or [])
            allowed = set(va.get("allowed_dimensions", []) or [])

            if dimension in denied:
                return GateResult("REJECTED", f"Scope mismatch: video scope '{va.get('declared_scope')}' denies dimension '{dimension}'.")

            if allowed and (dimension not in allowed):
                return GateResult("REJECTED", f"Scope mismatch: dimension '{dimension}' not in allowed_dimensions for this video asset (scope={va.get('declared_scope')}).")

            if (va.get("confidence", 0.0) < 0.65) or (va.get("requires_human_tag") is True) or (va.get("declared_scope") == "UNKNOWN"):
                return GateResult("PENDING", "Low-confidence title routing; manual tag verification required.")

        # 3) Confirmed cannot be supported by video alone
        if status == "confirmed" and video_assets:
            ev = claim.get("evidence", []) or []
            has_primary = any(e.get("evidence_type") in ("primary_raw", "primary_derived") for e in ev)
            if not has_primary:
                return GateResult("DOWNGRADED", "Video cannot confirm alone; downgraded to candidate until primary evidence exists.")

        return GateResult("APPROVED", "Claim passes video scope gates.")


    def validate_claim_bundle(self, bundle: Dict, evidence_assets: List[Dict]) -> Dict:
        """
        Validate all claims in an analysis claim bundle.
        Mutates claim statuses minimally:
          - DOWNGRADED => status candidate (with note)
          - REJECTED   => status rejected (with note)
          - PENDING    => status candidate (with note) and bundle flagged for manual review
        """
        claims = bundle.get("claims", []) or []
        manual_review = False

        for c in claims:
            res = self.validate_claim(c, evidence_assets)

            # Attach a gate note for traceability
            c.setdefault("notes", "")
            prefix = f"[SCOPE_GATE:{res.decision}] {res.reason}"
            c["notes"] = (prefix + (" " + c["notes"] if c["notes"] else "")).strip()

            if res.decision == "REJECTED":
                c["status"] = "rejected"
            elif res.decision == "DOWNGRADED":
                c["status"] = "candidate"
            elif res.decision == "PENDING":
                c["status"] = "candidate"
                manual_review = True

        if manual_review:
            bundle.setdefault("provenance", {}).setdefault("flags", [])
            if "requires_manual_video_tagging" not in bundle["provenance"]["flags"]:
                bundle["provenance"]["flags"].append("requires_manual_video_tagging")

        return bundle
