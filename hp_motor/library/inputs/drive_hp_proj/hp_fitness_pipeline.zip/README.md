# HP Fitness Pipeline (Sportsbase) — Machine-Friendly Data Contract + Importer

Bu paket, Sportsbase kaynaklı **Players fitness** ve **Team fitness** Excel export'larını
tek bir “canonical” şemaya normalize etmek ve **otomatik ingest/validasyon** yapmak için hazırlanmıştır.

## 1) Çıktı Tabloları (Grain)

### A) fitness_player_aggregate
- grain: `player × sheet_scope`
- sheet_scope: `competition_scope` (general/league/europe) × `aggregation_scope` (season_total/per_match_avg)

### B) fitness_team_match
- grain: `match × team`
- aynı maç için 2 satır beklenir (takım + rakip)
- Sportsbase dosyasında ikinci satırda context alanları boş geldiği için forward-fill uygulanır.

## 2) Çalıştırma

### Kurulum
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### Import + Validate
```bash
python -m hp_fitness.cli \
  --players "/path/to/Players fitness.xlsx" \
  --team    "/path/to/Team fitness.xlsx" \
  --outdir  "./out" \
  --format  parquet \
  --validate
```

Çıktılar:
- `out/fitness_player_aggregate.parquet`
- `out/fitness_team_match.parquet`
- `out/validation_report.json`

## 3) Data Contract
`contracts/fitness_contract.yml`:
- raw header → canonical field
- unit, type, zorunluluk, parse/clean kuralları

## 4) Validasyon (Sanity Checks)
Importer sonrasında otomatik kontroller:
- half sum: total ≈ (1h+2h)
- zones sum: total ≈ (walk+jog+run+hsr+sprint)
- open play: open_play ≈ (defense+offense)
- negative / impossible values
- score parsing & home/away derivation (team dosyası)

## 5) Notlar
“Defense/Offense” faz tanımı (possession mı, bölge mi), efor sayım algoritması (dwell time) gibi provider-belirleyici
tanımlar contract içinde `assumptions` olarak tutulur; Sportsbase dokümanı geldikçe `locked` yapılmalıdır.
