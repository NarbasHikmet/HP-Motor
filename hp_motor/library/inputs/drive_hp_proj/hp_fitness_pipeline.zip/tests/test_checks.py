import pandas as pd
from hp_fitness.validate.checks import validate_player, validate_team

def test_player_checks_smoke():
    df = pd.DataFrame({
        "distance_total_m": [1000.0],
        "distance_1h_m": [400.0],
        "distance_2h_m": [600.0],
        "distance_walk_m": [100.0],
        "distance_jog_m": [200.0],
        "distance_run_m": [300.0],
        "distance_hsr_m": [200.0],
        "distance_sprint_m": [200.0],
        "distance_open_play_m": [900.0],
        "distance_defense_m": [300.0],
        "distance_offense_m": [600.0],
    })
    checks = validate_player(df)
    assert any(c.name == "player_total_equals_halves" for c in checks)

def test_team_two_rows_per_match():
    df = pd.DataFrame({
        "match_key": ["a", "a"],
        "team_code": ["GAL", "OPP"],
        "distance_total_m": [10000.0, 9800.0],
        "distance_1h_m": [5000.0, 4800.0],
        "distance_2h_m": [5000.0, 5000.0],
        "distance_walk_m": [2000.0, 1900.0],
        "distance_jog_m": [3000.0, 2900.0],
        "distance_run_m": [3000.0, 2900.0],
        "distance_hsr_m": [1500.0, 1400.0],
        "distance_sprint_m": [500.0, 700.0],
        "score_for": [2, 1],
        "score_against": [1, 2],
    })
    checks = validate_team(df)
    c = [x for x in checks if x.name == "team_two_rows_per_match"][0]
    assert c.passed is True
