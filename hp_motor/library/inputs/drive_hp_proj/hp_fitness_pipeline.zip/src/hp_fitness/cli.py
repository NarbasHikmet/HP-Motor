from __future__ import annotations

import argparse
import json
from pathlib import Path

from hp_fitness.importers.sportsbase_fitness import normalize_players_excel, normalize_team_excel
from hp_fitness.validate.checks import validate_player, validate_team, report_to_dict


def _write(df, outpath: Path, fmt: str) -> None:
    outpath.parent.mkdir(parents=True, exist_ok=True)
    if fmt == "parquet":
        df.to_parquet(outpath, index=False)
    elif fmt == "csv":
        df.to_csv(outpath, index=False, encoding="utf-8-sig")
    else:
        raise ValueError(f"Unknown format: {fmt}")


def main() -> None:
    ap = argparse.ArgumentParser(description="Sportsbase fitness importer (HP canonical)")
    ap.add_argument("--players", required=True, help="Path to Players fitness.xlsx")
    ap.add_argument("--team", required=True, help="Path to Team fitness.xlsx")
    ap.add_argument("--outdir", required=True, help="Output directory")
    ap.add_argument("--format", choices=["parquet", "csv"], default="parquet")
    ap.add_argument("--validate", action="store_true", help="Run sanity checks and write validation report")
    args = ap.parse_args()

    outdir = Path(args.outdir)

    players = normalize_players_excel(args.players)
    team = normalize_team_excel(args.team)

    _write(players, outdir / f"fitness_player_aggregate.{args.format}", args.format)
    _write(team, outdir / f"fitness_team_match.{args.format}", args.format)

    if args.validate:
        checks = []
        checks.extend(validate_player(players))
        checks.extend(validate_team(team))
        report = report_to_dict(checks)
        (outdir / "validation_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    print("OK")
    print(f"players: {len(players):,} rows")
    print(f"team:    {len(team):,} rows")
    if args.validate:
        print("validation_report.json written")


if __name__ == "__main__":
    main()
