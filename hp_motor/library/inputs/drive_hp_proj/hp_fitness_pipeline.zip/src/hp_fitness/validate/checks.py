from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Dict, Any, List

import pandas as pd


@dataclass
class CheckResult:
    name: str
    passed: bool
    severity: str  # "error" | "warn"
    details: Dict[str, Any]


def _approx_equal(a: pd.Series, b: pd.Series, tol: float) -> pd.Series:
    mask = a.notna() & b.notna()
    ok = pd.Series(True, index=a.index)
    ok.loc[mask] = (a.loc[mask] - b.loc[mask]).abs() <= tol
    return ok


def validate_player(df: pd.DataFrame) -> List[CheckResult]:
    out: List[CheckResult] = []

    if {"distance_total_m", "distance_1h_m", "distance_2h_m"}.issubset(df.columns):
        rhs = df["distance_1h_m"] + df["distance_2h_m"]
        ok = _approx_equal(df["distance_total_m"], rhs, tol=10.0)
        out.append(CheckResult("player_total_equals_halves", bool(ok.all()), "warn",
                               {"failed_rows": int((~ok).sum())}))

    zone_cols = ["distance_walk_m", "distance_jog_m", "distance_run_m", "distance_hsr_m", "distance_sprint_m"]
    if set(zone_cols).issubset(df.columns) and "distance_total_m" in df.columns:
        rhs = df[zone_cols].sum(axis=1)
        ok = _approx_equal(df["distance_total_m"], rhs, tol=25.0)
        out.append(CheckResult("player_total_equals_zones", bool(ok.all()), "warn",
                               {"failed_rows": int((~ok).sum())}))

    if {"distance_open_play_m", "distance_defense_m", "distance_offense_m"}.issubset(df.columns):
        rhs = df["distance_defense_m"] + df["distance_offense_m"]
        ok = _approx_equal(df["distance_open_play_m"], rhs, tol=25.0)
        out.append(CheckResult("player_open_play_equals_def_plus_off", bool(ok.all()), "warn",
                               {"failed_rows": int((~ok).sum())}))

    num_cols = [c for c in df.columns if c.endswith(("_m", "_mps", "_kcal", "_wkg"))]
    if num_cols:
        neg = (df[num_cols] < 0).any(axis=1)
        out.append(CheckResult("player_no_negative_metrics", bool((~neg).all()), "error",
                               {"failed_rows": int(neg.sum())}))
    return out


def validate_team(df: pd.DataFrame) -> List[CheckResult]:
    out: List[CheckResult] = []

    if "match_key" in df.columns and "team_code" in df.columns:
        counts = df.groupby("match_key")["team_code"].nunique()
        bad = (counts != 2)
        out.append(CheckResult("team_two_rows_per_match", bool((~bad).all()), "warn",
                               {"bad_count": int(bad.sum())}))

    if {"distance_total_m", "distance_1h_m", "distance_2h_m"}.issubset(df.columns):
        rhs = df["distance_1h_m"] + df["distance_2h_m"]
        ok = _approx_equal(df["distance_total_m"], rhs, tol=25.0)
        out.append(CheckResult("team_total_equals_halves", bool(ok.all()), "warn",
                               {"failed_rows": int((~ok).sum())}))

    zone_cols = ["distance_walk_m", "distance_jog_m", "distance_run_m", "distance_hsr_m", "distance_sprint_m"]
    if set(zone_cols).issubset(df.columns) and "distance_total_m" in df.columns:
        rhs = df[zone_cols].sum(axis=1)
        ok = _approx_equal(df["distance_total_m"], rhs, tol=50.0)
        out.append(CheckResult("team_total_equals_zones", bool(ok.all()), "warn",
                               {"failed_rows": int((~ok).sum())}))

    if {"score_for", "score_against"}.issubset(df.columns):
        ok = df["score_for"].notna() & df["score_against"].notna()
        out.append(CheckResult("team_score_parsed", bool(ok.all()), "warn",
                               {"failed_rows": int((~ok).sum())}))

    num_cols = [c for c in df.columns if c.endswith(("_m", "_mps", "_kcal", "_wkg"))]
    if num_cols:
        neg = (df[num_cols] < 0).any(axis=1)
        out.append(CheckResult("team_no_negative_metrics", bool((~neg).all()), "error",
                               {"failed_rows": int(neg.sum())}))
    return out


def report_to_dict(checks: List[CheckResult]) -> Dict[str, Any]:
    return {"passed": all(c.passed or c.severity != "error" for c in checks),
            "checks": [asdict(c) for c in checks]}
