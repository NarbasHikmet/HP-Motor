from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

PLAYER_MAP: Dict[str, str] = {
    "player_number": "№",
    "player_name": "Oyuncu",
    "age_years": "Yaş",
    "height_cm": "Boy",
    "weight_kg": "Kilo",
    "nationality": "Ülkesi",
    "minutes_played": "Oynadığı süre",
    "distance_total_m": "Distance, m.",
    "distance_1h_m": "Distance 1st half, m.",
    "distance_2h_m": "Distance 2nd half, m.",
    "distance_open_play_m": "Open play distance, m.",
    "distance_defense_m": "Distance in defense, m.",
    "distance_offense_m": "Distance in offense, m.",
    "distance_hsr_m": "High speed distance (5.51 - 7 m/s), m.",
    "distance_hsr_1h_m": "High speed distance (5.51 - 7 m/s) 1st half, m.",
    "distance_hsr_2h_m": "High speed distance (5.51 - 7 m/s) 2nd half, m.",
    "distance_sprint_m": "Sprint distance (> 7 m/s), m.",
    "distance_sprint_1h_m": "Sprint distance (> 7 m/s) 1st half, m.",
    "distance_sprint_2h_m": "Sprint distance (> 7 m/s) 2nd half, m.",
    "hsr_count": "Number of high speed runs",
    "sprint_count": "Number of sprints",
    "avg_speed_mps": "Average speed, m/s",
    "distance_walk_m": "Walk distance (<= 2 m/s), m.",
    "distance_walk_1h_m": "Walk distance (<= 2 m/s) 1st half, m.",
    "distance_walk_2h_m": "Walk distance (<= 2 m/s) 2nd half, m.",
    "distance_jog_m": "Jog distance (2,01 - 4 m/s), m.",
    "distance_jog_1h_m": "Jog distance (2,01 - 4 m/s) 1st half, m.",
    "distance_jog_2h_m": "Jog distance (2,01 - 4 m/s) 2nd half, m.",
    "distance_run_m": "Run distance (4.01 - 5.5 m/s), m.",
    "distance_run_1h_m": "Run distance (4.01 - 5.5 m/s) 1st half, m.",
    "distance_run_2h_m": "Run distance (4.01 - 5.5 m/s) 2nd half, m.",
    "distance_hsr_def_m": "High speed distance (5.51 - 7 m/s) in defense, m.",
    "distance_hsr_off_m": "High speed distance (5.51 - 7 m/s) in offense, m.",
    "distance_sprint_def_m": "Sprint distance (> 7 m/s) in defense, m.",
    "distance_sprint_off_m": "Sprint distance (> 7 m/s) in offense, m.",
    "hsr_count_1h": "Number of high speed runs 1st half",
    "hsr_count_2h": "Number of high speed runs 2nd half",
    "sprint_count_1h": "Number of sprints 1st half",
    "sprint_count_2h": "Number of sprints 2nd half",
    "hi_actions_count": "Number of high speed runs and sprints",
    "avg_speed_ball_in_play_mps": "Average speed (ball in play time), m/s",
    "max_speed_mps": "Maximum speed, m/s",
    "energy_kcal": "Energy expence, kcal.",
    "avg_metabolic_power_wkg": "Average metabolic power, w/kg",
}

TEAM_MAP: Dict[str, str] = {
    "match_datetime": "Tarih",
    "home_away_focus": "h / a",
    "opponent_name": "Opponent",
    "score_raw": "Score",
    "team_code": "Takım",
    "distance_total_m": "Distance, m.",
    "distance_1h_m": "Distance 1st half, m.",
    "distance_2h_m": "Distance 2nd half, m.",
    "distance_walk_m": "Walk distance (<= 2 m/s), m.",
    "distance_walk_1h_m": "Walk distance (<= 2 m/s) 1st half, m.",
    "distance_walk_2h_m": "Walk distance (<= 2 m/s) 2nd half, m.",
    "distance_jog_m": "Jog distance (2,01 - 4 m/s), m.",
    "distance_jog_1h_m": "Jog distance (2,01 - 4 m/s) 1st half, m.",
    "distance_jog_2h_m": "Jog distance (2,01 - 4 m/s) 2nd half, m.",
    "distance_run_m": "Run distance (4.01 - 5.5 m/s), m.",
    "distance_run_1h_m": "Run distance (4.01 - 5.5 m/s) 1st half, m.",
    "distance_run_2h_m": "Run distance (4.01 - 5.5 m/s) 2nd half, m.",
    "distance_hsr_m": "High speed distance (5.51 - 7 m/s), m.",
    "distance_hsr_1h_m": "High speed distance (5.51 - 7 m/s) 1st half, m.",
    "distance_hsr_2h_m": "High speed distance (5.51 - 7 m/s) 2nd half, m.",
    "distance_hsr_def_m": "High speed distance (5.51 - 7 m/s) in defense, m.",
    "distance_hsr_off_m": "High speed distance (5.51 - 7 m/s) in offense, m.",
    "distance_sprint_m": "Sprint distance (> 7 m/s), m.",
    "distance_sprint_1h_m": "Sprint distance (> 7 m/s) 1st half, m.",
    "distance_sprint_2h_m": "Sprint distance (> 7 m/s) 2nd half, m.",
    "distance_sprint_def_m": "Sprint distance (> 7 m/s) in defense, m.",
    "distance_sprint_off_m": "Sprint distance (> 7 m/s) in offense, m.",
    "hsr_count": "Number of high speed runs",
    "hsr_count_1h": "Number of high speed runs 1st half",
    "hsr_count_2h": "Number of high speed runs 2nd half",
    "sprint_count": "Number of sprints",
    "sprint_count_1h": "Number of sprints 1st half",
    "sprint_count_2h": "Number of sprints 2nd half",
    "hi_actions_count": "Number of high speed runs and sprints",
    "team_avg_player_speed_mps": "Average speed of a field player, m/s",
    "team_avg_player_max_speed_mps": "Average max. speed of a field player, m/s",
    "team_avg_player_energy_kcal": "Average energy expence of a field player, kcal.",
}

def _sheet_scope_players(sheet_name: str) -> Tuple[str, str]:
    s = sheet_name.lower()
    competition = "general"
    if "lig" in s:
        competition = "league"
    elif "avrupa" in s:
        competition = "europe"

    aggregation = "season_total"
    if "maç başı" in s or "mac basi" in s:
        aggregation = "per_match_avg"
    return competition, aggregation

def _sheet_scope_team(sheet_name: str) -> Tuple[str, str]:
    s = sheet_name.lower()
    competition = "general"
    if "lig" in s:
        competition = "league"
    elif "avrupa" in s:
        competition = "europe"

    result = "all"
    if "galibiyet" in s:
        result = "win"
    elif "beraberlik" in s:
        result = "draw"
    elif "mağlubiyet" in s or "maglubiyet" in s:
        result = "loss"
    return competition, result

def _parse_score(score_raw: object) -> Tuple[float, float]:
    m = re.match(r"^\s*(\d+)\s*:\s*(\d+)\s*$", str(score_raw))
    if not m:
        return (np.nan, np.nan)
    return float(m.group(1)), float(m.group(2))

def _coerce_numeric(series: pd.Series) -> pd.Series:
    if series.dtype.kind in "biufc":
        return pd.to_numeric(series, errors="coerce")
    s = series.astype(str).str.strip().replace({"": np.nan, "nan": np.nan, "None": np.nan})
    s = s.str.replace(" ", "", regex=False).str.replace(",", ".", regex=False)
    return pd.to_numeric(s, errors="coerce")

def normalize_players_excel(path: str | Path, provider: str = "sportsbase") -> pd.DataFrame:
    path = Path(path)
    xls = pd.ExcelFile(path)
    frames: List[pd.DataFrame] = []

    for sheet in xls.sheet_names:
        df = pd.read_excel(path, sheet_name=sheet)
        competition_scope, aggregation_scope = _sheet_scope_players(sheet)

        out = pd.DataFrame()
        out["provider"] = provider
        out["source_file"] = path.name
        out["source_sheet"] = sheet
        out["competition_scope"] = competition_scope
        out["aggregation_scope"] = aggregation_scope

        for canon, raw_col in PLAYER_MAP.items():
            out[canon] = df.get(raw_col)

        metric_cols = [c for c in out.columns if c.endswith(("_m", "_mps", "_kcal", "_wkg"))]
        for c in metric_cols:
            out[c] = _coerce_numeric(out[c])

        int_cols = [
            "player_number", "age_years", "height_cm", "weight_kg", "minutes_played",
            "hsr_count", "sprint_count", "hsr_count_1h", "hsr_count_2h",
            "sprint_count_1h", "sprint_count_2h", "hi_actions_count",
        ]
        for c in int_cols:
            if c in out.columns:
                out[c] = _coerce_numeric(out[c]).round().astype("Int64")

        frames.append(out)

    return pd.concat(frames, ignore_index=True)

def normalize_team_excel(path: str | Path, provider: str = "sportsbase") -> pd.DataFrame:
    path = Path(path)
    xls = pd.ExcelFile(path)
    frames: List[pd.DataFrame] = []

    for sheet in xls.sheet_names:
        raw = pd.read_excel(path, sheet_name=sheet)
        competition_scope, result_scope = _sheet_scope_team(sheet)

        is_focus_row = raw.get("Opponent").notna() if "Opponent" in raw.columns else pd.Series(False, index=raw.index)

        ffill_cols = [c for c in ["Tarih", "h / a", "Opponent", "Score"] if c in raw.columns]
        if ffill_cols:
            raw[ffill_cols] = raw[ffill_cols].ffill()

        raw["match_key"] = raw["Tarih"].astype(str) + "|" + raw["Opponent"].astype(str) + "|" + raw["Score"].astype(str)

        focus_team = raw.loc[is_focus_row, ["match_key", "Takım"]].set_index("match_key")["Takım"].to_dict()
        teams_per_match = raw.groupby("match_key")["Takım"].apply(lambda s: list(pd.unique(s.dropna()))).to_dict()

        def match_opponent(key: str) -> Optional[str]:
            teams = teams_per_match.get(key, [])
            ft = focus_team.get(key)
            if ft and len(teams) == 2:
                return teams[0] if teams[1] == ft else teams[1]
            return None

        opp_per_match = {k: match_opponent(k) for k in teams_per_match}

        out = pd.DataFrame()
        out["provider"] = provider
        out["source_file"] = path.name
        out["source_sheet"] = sheet
        out["competition_scope"] = competition_scope
        out["result_scope"] = result_scope
        out["match_key"] = raw["match_key"]

        for canon, raw_col in TEAM_MAP.items():
            out[canon] = raw.get(raw_col)

        out["focus_team"] = out["match_key"].map(focus_team)
        out["match_opponent"] = out["match_key"].map(opp_per_match)

        def opponent_code(row) -> Optional[str]:
            teams = teams_per_match.get(row["match_key"], [])
            if len(teams) != 2:
                return None
            return teams[0] if teams[1] == row["team_code"] else teams[1]

        out["opponent_code"] = out.apply(opponent_code, axis=1)

        out["home_team"] = np.where(out["home_away_focus"].astype(str).str.lower().eq("h"),
                                    out["focus_team"], out["match_opponent"])
        out["home_away"] = np.where(out["team_code"].eq(out["home_team"]), "h", "a")

        score_parsed = out["score_raw"].map(_parse_score)
        out["score_home"] = [x[0] for x in score_parsed]
        out["score_away"] = [x[1] for x in score_parsed]

        out["score_for"] = np.where(out["home_away"].eq("h"), out["score_home"], out["score_away"])
        out["score_against"] = np.where(out["home_away"].eq("h"), out["score_away"], out["score_home"])

        out["result"] = np.where(
            out["score_for"] > out["score_against"], "W",
            np.where(out["score_for"] < out["score_against"], "L", "D")
        )

        metric_cols = [c for c in out.columns if c.endswith(("_m", "_mps", "_kcal", "_wkg"))]
        for c in metric_cols:
            out[c] = _coerce_numeric(out[c])

        int_cols = ["hsr_count", "hsr_count_1h", "hsr_count_2h", "sprint_count",
                    "sprint_count_1h", "sprint_count_2h", "hi_actions_count",
                    "score_home", "score_away", "score_for", "score_against"]
        for c in int_cols:
            if c in out.columns:
                out[c] = _coerce_numeric(out[c]).round().astype("Int64")

        frames.append(out)

    return pd.concat(frames, ignore_index=True)
