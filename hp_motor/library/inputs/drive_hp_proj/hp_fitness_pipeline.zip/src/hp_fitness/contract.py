from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional, Any, List

import yaml


@dataclass(frozen=True)
class FieldSpec:
    canonical: str
    raw: str
    unit: str
    dtype: str
    required: bool = False
    notes: Optional[str] = None


@dataclass(frozen=True)
class FitnessContract:
    version: str
    provider: str
    dataset: str
    fields: List[FieldSpec]
    assumptions: Dict[str, Any]

    @property
    def by_canonical(self) -> Dict[str, FieldSpec]:
        return {f.canonical: f for f in self.fields}

    @property
    def by_raw(self) -> Dict[str, FieldSpec]:
        return {f.raw: f for f in self.fields}


def load_contract(path: str | Path) -> FitnessContract:
    path = Path(path)
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    fields = [
        FieldSpec(
            canonical=f["canonical"],
            raw=f["raw"],
            unit=f.get("unit", ""),
            dtype=f.get("type", "string"),
            required=bool(f.get("required", False)),
            notes=f.get("notes"),
        )
        for f in data.get("fields", [])
    ]
    return FitnessContract(
        version=str(data.get("version", "0.0.0")),
        provider=str(data.get("provider", "unknown")),
        dataset=str(data.get("dataset", "fitness")),
        fields=fields,
        assumptions=dict(data.get("assumptions", {})),
    )
