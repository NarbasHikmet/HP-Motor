# HP Engine - Otonom Analiz Sistemi

Bu paket; HP Engine icin moduler mimari, veri semalari, yol haritasi ve ornek config dosyalarini icerir.

- Tarih: 2026-01-19
- UI: Streamlit
- API: FastAPI + Uvicorn
- Kaynak veri: SportsBase, WhoScored, FBRef

## Icerik
- HP_Engine_Otonom_Analiz_Sistemi.docx : Tasarim dokumani
- hp_engine_spec.yaml : Moduller/pipeline semasi (AI/makine dostu)
- requirements.txt : Paket seti

## Calistirma (ornegi)
1) requirements.txt kur
2) api/main.py (FastAPI)
3) app/app.py (Streamlit)

## Not
Video + pose modulleri Ar-Ge asamasinda GPU ihtiyaci dogurabilir.
