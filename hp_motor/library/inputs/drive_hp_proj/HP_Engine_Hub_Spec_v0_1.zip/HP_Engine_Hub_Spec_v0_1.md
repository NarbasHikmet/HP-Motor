# HP Engine Hub – Kodlamaya Hazır Spesifikasyon (v0.1)

> Amaç: Bu doküman, bugün konuştuğumuz **HP Engine analiz modlarını** ve **maç/oyuncu/takım/rakip/transfer analizinin nasıl yapıldığını**; **otomasyona** ve **yapay zekâya öğretilebilir** şekilde **tek bir “source of truth”** formatında tanımlar.  
> Tasarım ilkesi: **Şeytan ayrıntıda gizlidir** → her çıktıda *tez/kanıt/risk/müdahale/KPI* zorunluluğu, kör nokta kontrolleri, veri–taktik–psikodinamik senkronu.

---

## 1) Kapsam

Bu spesifikasyon şunları kapsar:
- **Çekirdek analiz üçgeni:** Veri / Taktik / Psikodinamik
- **HP Engine Analiz Modları (9):**
  1. Pre-Match  
  2. Post-Match  
  3. Individual Analysis  
  4. Team Analysis  
  5. Opposition Analysis  
  6. Seasonal/Tournaments Analysis  
  7. Scouting Analysis  
  8. Team Engineering  
  9. Transfer Motor
- Her mod için: **Amaç, Girdi, Çıktı, KPI, Kör Nokta** + **adım adım workflow**.
- **Standardize edilmiş “HP Output Canon”**: Her mod *aynı iskeleti* üretir.
- **Otomasyon mimarisi**: ingest → normalizasyon → analiz katmanları → mod orkestrasyonu → kalite kontrol → yayın/rapor çıktısı.

Kapsam dışı (v0.1): canlı maç içi gerçek zamanlı entegrasyon (gelecek mod olarak önerilir).

---

## 2) Çekirdek model: Veri–Taktik–Psikodinamik

**Veri katmanı (Evidence-Data):**
- xG / xT / zone progression, şut zinciri, pas ağı, baskı aksiyonları, top kazanım bölgeleri, geçiş yeme/üretme metrikleri.
- Amaç: *ölçülebilir kanıt* üretmek.

**Taktik katmanı (Mechanism-Tactics):**
- Oyun modeli, fazlar (set hücum / geçiş / set savunma / duran top)
- Yapı & alan kullanımı (koridor/half-space/3. adam), pres & tetikler, rest-defence, eşleşmeler.
- Amaç: *nasıl oldu*yu açıklamak.

**Psikodinamik katman (Psycho-Dynamics):**
- Momentum, stres tepkisi, liderlik/iletişim, karar kalitesi ve hızına etki eden bağlamsal faktörler.
- Amaç: *neden böyle karar verdiler* ve *kırılma anı* açıklamak.

> Not: v0.1’de psikodinamik, “kanıt üçlemesi” içinde 3. bir kanıt türü olarak değil; **Risk** ve **Müdahale** üretiminde “bağlam çarpanı” olarak kullanılır.

---

## 3) HP Output Canon (Zorunlu Çıktı İskeleti)

Her mod çıktısı aşağıdaki 5 parçayı **zorunlu** içerir:

1) **Tez (1 cümle)**  
2) **Kanıt (3 madde)**  
   - **1 Veri kanıtı** (metrik/ölçüm)  
   - **1 Klip/sekans kanıtı** (timestamp/olay dizisi)  
   - **1 Taktik işaret** (yapı, tetik, eşleşme, faz göstergesi)  
3) **Risk (1 madde)**  
4) **Müdahale (2 seçenek)**  
   - Düşük risk / yüksek güven  
   - Daha agresif / yüksek getiri  
5) **KPI (3 ölçüt)**

**Kalite zorunlulukları:**
- En az **1 alternatif hipotez** (result-bias kontrolü)
- “Skor analizi ele geçirmesin” kontrolü (post-match için kritik)
- “Rakip ideal oynar” varsayımı kontrolü (pre-match için kritik)
- Her çıktıda **kırılgan bölge** (red zone) belirtilir.

---

## 4) Modlar arası hiyerarşi ve akış

**Oyun günü çekirdeği:** `Pre-Match → Post-Match`  
**Sistem katmanı:** `Team Analysis + Opposition Analysis`  
**Mikro katman:** `Individual Analysis`  
**Makro katman:** `Seasonal/Tournaments Analysis`  
**Kadrosal işletim:** `Scouting → Team Engineering → Transfer Motor`

---

## 5) Veri modeli (AI’ye öğretilebilir ontoloji)

### 5.1 Temel varlıklar (Entities)
- **Match**: maç meta + skor + kadrolar + olaylar + video kaynakları
- **Team**: takım kimliği + oyun modeli profili + sezon trendleri
- **Player**: oyuncu kimliği + rol profili + aksiyon kayıtları
- **Opponent**: rakip takıma ilişkin özel view (Team’in bir alt görünümü)
- **Competition / Season / Tournament**
- **Event**: pas, şut, top kaybı, pres, top kazanımı, faul, duran top, vb.
- **Sequence**: olay zinciri (örn. top kazanımı → 3 pas → half-space giriş → şut)
- **Phase**: set hücum / geçiş / set savunma / duran top
- **TacticalPattern**: pres tuzağı, yönlendirme, 3. adam, overload/underload vb.
- **RiskVector**: rest-defence kırığı, 2. top zafiyeti, kanal savunması vb.
- **Intervention**: rol değişimi, tetik ayarı, yönlendirme, tempo, blok yüksekliği
- **Evidence**: veri / klip / taktik işaret
- **KPI**: ölçümler

### 5.2 İlişkiler (Relations)
- Match contains Events & Sequences
- Sequence belongs_to Phase
- TacticalPattern detected_in Sequence
- Player performs Event
- Team owns GameModelProfile
- Intervention targets Team/Player/Structure
- Evidence supports Thesis
- RiskVector derived_from Evidence + Context

---

## 6) Orkestrasyon mimarisi (Pipeline)

### 6.1 Aşamalar
1. **Ingest**
2. **Normalize**
3. **Context Builder**
4. **Feature Extraction**
5. **Tactical Inference**
6. **Synthesis (HP Output Canon)**
7. **Quality Gates**
8. **Narrative Generator**

### 6.2 Otomasyon prensipleri
- **Rule + Model hibriti**
- **Deterministik izlek (audit trail)**
- **Kontradiksiyon tespiti**

---

## 7) Analiz modları – Tanım seti (9)

Bu bölüm, her mod için: amaç, girdi, çıktı, KPI, kör nokta ve deterministik workflow içerir.  
Detaylı konfigürasyonlar ayrıca `configs/hp_mode_configs.v0_1.json` dosyasında verilir.

---

## 8) Kalite Kapıları (Quality Gates) – Kodlanabilir kontrol listesi

- **G1 – Canon Completeness**
- **G2 – Evidence Traceability**
- **G3 – Blindspot Check**
- **G4 – Alternative Hypothesis**
- **G5 – Contradiction Check**
- **G6 – Red Zone**
- **G7 – Scenario Coverage (Pre-Match)**
- **G8 – Resulting Guard (Post-Match)**

---

## 9) API yüzeyi (öneri)

- `POST /hub/analyze`
- `POST /hub/extract/events`
- `POST /hub/extract/sequences`
- `POST /hub/infer/tactical-patterns`
- `POST /hub/report/render`
- `GET  /hub/audit/{report_id}`

---

## 10) Loglama ve Audit Trail

Her rapor nesnesi şunları loglamalı:
- `input_hash`
- `evidence_map`
- `quality_gate_results`
- `version`
- `diff`

---

## 11) Gelecekte eklenebilecek modlar (opsiyonel)

- In-Game Live Mod
- Training/Development Mod
- Medical/Load Mod

---

## 12) Uygulama notları (kritik)

- Veri yoksa “kanıt uydurma” yok.
- Klip kanıtı: mümkünse timestamp; yoksa Sequence ID.
- Bağlam şart: skor/dakika/maç dönemi her kritik sekansla birlikte.
- Rol sözlüğü: Team Engineering + Scouting + Individual aynı RoleSpec’i kullanır.

---

# Ek: JSON Şema (özet)

Aşağıdaki şema dosyalar halinde verildi (bu paketle birlikte).


## Ek: Örnek `HPReport` (Pre-Match)

```json
{
  "report_id": "rep_2025_12_24_001",
  "version": "0.1",
  "mode_id": "pre_match",
  "subject": {
    "match_id": "m_12345",
    "team_id": "team_A",
    "opponent_id": "team_B"
  },
  "thesis": "Rakibin sağ koridor yüklenmesi ve ikinci topları, bizim rest-defence dengemizi kırıyor; pres yönlendirmesini sol çizgiye zorlayıp half-space girişlerini kesersek maçın kontrolünü alırız.",
  "evidence": [
    {
      "evidence_id": "ev_data_01",
      "type": "data",
      "summary": "Rakip son 6 maçta sağ koridor kaynaklı %38 final-third giriş üretti.",
      "payload": {
        "metric": "corridor_entries_share",
        "value": 0.38,
        "sample": 6
      }
    },
    {
      "evidence_id": "ev_clip_07",
      "type": "clip",
      "summary": "Dakika 12:10–12:45: sağ koridor overload → cutback şut sekansı.",
      "payload": {
        "video_ref": "vid_abc",
        "start": "12:10",
        "end": "12:45"
      }
    },
    {
      "evidence_id": "ev_tac_03",
      "type": "tactical_sign",
      "summary": "Rakip 8 numara half-space’e 3. adam koşusuyla giriyor; bizim 6’nın gölgesi gecikiyor.",
      "payload": {
        "pattern": "third_man_run",
        "zone": "right_half_space"
      }
    }
  ],
  "risk": "Erken top kaybında sağ half-space arkası boşalırsa geçişte 2v2 yakalanıyoruz.",
  "interventions": [
    {
      "type": "low_risk",
      "description": "Pres yönlendirmesini sol çizgiye kilitle, 6 numara half-space gölgesini erkenden al; bek- stoper arası mesafeyi daralt.",
      "risk_level": "low",
      "expected_uplift": "Geçiş yemeyi azaltır, rakibin ana koridorunu boğar."
    },
    {
      "type": "high_upside",
      "description": "Önde agresif tuzak: sağ bek üzerine tetik; top kazanımından sonra 2 pasla ters kanat hızlı çıkış.",
      "risk_level": "medium",
      "expected_uplift": "Yüksek top kazanım bölgeleriyle hızlı skor üretimi."
    }
  ],
  "kpis": [
    {
      "name": "Ball recoveries in left flank",
      "definition": "Rakibi sol çizgiye yönlendirip kazandığımız toplar",
      "target": 8,
      "actual": null
    },
    {
      "name": "Transitions conceded",
      "definition": "Top kaybı sonrası 10 sn içinde rakip final-third girişi",
      "target": 3,
      "actual": null
    },
    {
      "name": "Half-space entries allowed (right)",
      "definition": "Rakibin sağ half-space’e kontrollü giriş sayısı",
      "target": 5,
      "actual": null
    }
  ],
  "quality_gates": {
    "G1": true,
    "G2": true,
    "G3": true,
    "G4": true,
    "G5": true,
    "G6": true,
    "G7": true,
    "G8": false
  },
  "audit": {
    "input_hash": "sha256:...",
    "evidence_map": {
      "thesis": [
        "ev_data_01",
        "ev_clip_07",
        "ev_tac_03"
      ]
    },
    "created_at": "2025-12-24T12:00:00+03:00",
    "model_version": "llm_x.y",
    "rule_version": "rules_0.1"
  }
}
```
