
# Sohbet Fişi — HP Engine / Yapay Zeka Destekli Futbol Video Analizi Entegrasyonu (Tek Sayfa)

## 1) Amaç
“HP Engine” için futbol video analiz pipeline’ını (Ingestion → Detection → Tracking → Homography → Smoothing → Metrics → Validation → Export) bilimsel temellerle (EP TS/FIFA, Linke 2020 benchmark mantığı, modern CV yöntemleri) uyumlu şekilde repo içine entegre edilebilir bir iskelet olarak kurmak.

Rapor metnini “kütüphane” formatında repo içine alıp, canon (şema/sözlük) ile metrik isimlendirmesine bağlamak.

---

## 2) Girdi / Varlıklar
- Kullanıcının hazırladığı kapsamlı rapor metni (clipboard üzerinden kaydedildi).
- GitHub repo (ZIP): HP_Engine-main.zip
- Ek bilimsel kütüphane dosyası:
  HP_Scientific_Library.json

---

## 3) Çalışılan Dizinler (Kritik)
### Asıl Repo Çalışma Dizini
HP_Engine_Work/HP_Engine  
(app.py, requirements.txt, canon/, engine/ doğrulandı)

### Geçici / Sandbox Dizini
Masaüstü/HP_Engine  
(paralel iskelet; single source of truth riski)

---

## 4) Yapılan İşler (Gerçekleşen)
- ZIP path problemi çözüldü, repo doğru dizine taşındı.
- canon/video_metrics_patch.yaml üretildi ve doğrulandı.
- engine/video altında modüler iskelet kuruldu.
- Placeholder dosyalar ve requirements-video.txt eklendi.

---

## 5) Sorunlar / Blokajlar
- docs/ klasörü repo kökünde yok.
- sklearn paketi deprecated → scikit-learn kullanılmalı.
- İki ayrı HP_Engine dizini single source of truth riskini doğuruyor.

---

## 6) Mevcut Durum Özeti
- Doğru repo dizini aktif.
- canon patch hazır.
- video pipeline iskeleti hazır.
- docs/ eksik.
- Paket kurulum hatası tespit edildi.
- Sandbox kodu repoya entegre edilmedi.

---

## 7) Mimari Kararlar
- Video modülü engine/video altında kalmalı.
- Rapor metni backlog + kalite kapısı işlevi görmeli.
- Canon, video metriklerini VideoTracking.* namespace’i ile yönetmeli.

---

## 8) Hedef Artefact Standardı
artifacts/video_runs/run_<timestamp>/
- metrics.json
- gates.json
- report.md
- tracking.parquet (opsiyonel)

---

## 9) Not
Bu dosya yalnızca durum tespiti ve bağlam kilidi içindir.
Uygulama adımlarını içermez.
