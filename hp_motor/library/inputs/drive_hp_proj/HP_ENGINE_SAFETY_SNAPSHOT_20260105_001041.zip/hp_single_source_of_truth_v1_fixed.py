# hp_single_source_of_truth_v1_fixed.py
# ============================================================
# HP SINGLE SOURCE OF TRUTH (SOT) — v1 (FIXED / NO-GUESSING)
# ------------------------------------------------------------
# PURPOSE
#   Tek dosyada HP Engine karar kilitleri + kontratlar + guardrails + roadmap'i
#   makine-dostu bir registry/manifest olarak paketler.
#
# USAGE
#   python hp_single_source_of_truth_v1_fixed.py > hp_sot_v1.json
#   python hp_single_source_of_truth_v1_fixed.py --patch > hp_sot_patch_v1.json
#
# NON-NEGOTIABLE (this build)
#   - NO GUESSING: Veri tanımlama/algılama/analiz aşamalarında heuristik yok.
#   - UNKNOWN => STOP: Bilinmeyen alan/metric/event varsa analiz&grafik üretilmez.
#   - MUTABAKAT: Sistem "questions_to_resolve.json" üretir; kararlar decisions.json'a yazılmadan devam etmez.
# ============================================================

from __future__ import annotations

import argparse
import json
import hashlib
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Literal, Optional, Tuple

def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()

def _sha16(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]

def _dump(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, indent=2)

Status = Literal["draft", "active", "merged", "deprecated"]
ArtifactKind = Literal["file", "spec", "code", "rulepack", "prompt", "contract", "registry", "dataset", "note"]
Layer = Literal["core", "memory", "audit", "studio", "ui", "enrichment", "orchestrator", "prompting", "contracts", "tools"]

@dataclass
class ArtifactRef:
    name: str
    kind: ArtifactKind
    status: Literal["created", "updated", "planned"] = "created"
    uri: Optional[str] = None
    purpose: str = ""
    example_usage: str = ""

@dataclass
class GateRule:
    id: str
    description: str
    level: Literal["hard", "soft"] = "hard"
    applies_to: List[str] = field(default_factory=list)
    enforcement: Literal["fail_closed", "warn_and_continue"] = "fail_closed"
    error_code: Optional[str] = None
    user_question_id: Optional[str] = None

@dataclass
class RiskItem:
    id: str
    risk: str
    failure_mode: str
    mitigation: str
    owner_layer: Layer
    severity: Literal["low", "med", "high"] = "high"

@dataclass
class DecisionLock:
    id: str
    statement: str
    rationale: str
    scope: List[str] = field(default_factory=list)
    change_policy: Literal["v1_locked_new_version_required", "editable"] = "v1_locked_new_version_required"

@dataclass
class ResolutionQuestion:
    id: str
    subject: str
    context: Dict[str, Any] = field(default_factory=dict)
    options: List[Dict[str, Any]] = field(default_factory=list)
    recommended_action: Optional[str] = None
    blocking: bool = True
    answer_schema: Dict[str, Any] = field(default_factory=dict)

@dataclass
class ResolutionProtocol:
    unknown_policy: Literal["stop_and_ask", "warn_and_continue"] = "stop_and_ask"
    question_output_path: str = "questions_to_resolve.json"
    decision_log_path: str = "decisions.json"
    resume_requires_decision_log: bool = True
    never_guess: bool = True

@dataclass
class MetricRegistryContract:
    required_fields: List[str]
    pct_requires_dependencies: bool = True
    pct_dependency_fields: Tuple[str, str] = ("numerator_metric_id", "denominator_metric_id")
    forbid_missing_unit: bool = True
    forbid_missing_granularity: bool = True

@dataclass
class IndexRegistryContract:
    required_fields: List[str]
    forbid_mixed_phase_inputs: bool = True
    forbid_count_pct_mix_without_normalization: bool = True

@dataclass
class UIContract:
    allowed_layers: List[str]
    forbidden_patterns: List[str]

@dataclass
class CaravaggioGraphMetaContract:
    required_graph_meta_fields: List[str]
    forbidden_patterns: List[str]
    marker_contract_fixed: Dict[str, str]

@dataclass
class HPSystemDefinition:
    name: str
    mission: str
    non_negotiables: List[str]
    layers: Dict[str, List[str]]
    truth_artifacts: List[str]
    default_gates: Dict[str, Any]
    assumptions: List[str]
    resolution_protocol: ResolutionProtocol

Entity = Literal["player", "team", "unit"]
Normalization = Literal["per90", "percentile", "zscore"]
BenchmarkGroup = Literal["league", "competition", "position"]
ExportLevel = Literal["analysis", "broadcast"]
FailPolicy = Literal["fail_closed", "warn_and_continue"]

MetricRole = Literal[
    "production", "progression", "defensive", "coordination", "context",
    "goalkeeping", "discipline", "other"
]
Directionality = Literal["higher_better", "lower_better", "neutral"]
MinutesBasis = Literal["played_minutes", "on_pitch_minutes", "effective_minutes"]
WindowType = Literal["season", "rolling_matches", "rolling_days"]

RadarKind = Literal["player", "team", "unit"]
ClampMode = Literal["none", "p01_p99", "p05_p95"]

@dataclass(frozen=True)
class HeatmapContract:
    team_selector: str
    scope: Literal["all_actions", "filtered_actions"]
    half: Optional[Literal[1, 2]] = None
    minute_range: Optional[Tuple[int, int]] = None
    attacks_right_1h: bool = True
    render_preset: Literal["sportsbase_light", "sportsbase_dark", "sportsbase_template"] = "sportsbase_dark"
    bins: Tuple[int, int] = (36, 24)
    blur_sigma: float = 1.7
    percentile_clip: int = 92

HP_SPADL_V1_EVENT_MAP = {
    "version": "hp-spadl-v1",
    "description": "Sportsbase event export -> HP canonical action language (SPADL-like). NO-GUESSING.",
    "principles": ["single_path", "non_discard", "event_level_only", "no_guessing"],
    "canonical_actions": {
        "PASS": {"sportsbase_event_type_values": [], "phase_allowed": ["in_possession","transition"]},
        "SHOT": {"sportsbase_event_type_values": [], "phase_allowed": ["in_possession"]},
        "CARRY": {"sportsbase_event_type_values": [], "phase_allowed": ["in_possession","transition"]},
        "DRIBBLE": {"sportsbase_event_type_values": [], "phase_allowed": ["in_possession"]},
        "DUEL": {"sportsbase_event_type_values": [], "phase_allowed": ["in_possession","out_of_possession"]},
        "RECOVERY": {"sportsbase_event_type_values": [], "phase_allowed": ["transition"]},
        "TURNOVER": {"sportsbase_event_type_values": [], "phase_allowed": ["transition"]},
        "PRESSURE": {"sportsbase_event_type_values": [], "phase_allowed": ["out_of_possession"]},
        "FOUL": {"sportsbase_event_type_values": [], "phase_allowed": ["set_piece","out_of_possession"]},
        "UNKNOWN": {"sportsbase_event_type_values": [], "phase_allowed": ["in_possession","out_of_possession","transition","set_piece"]},
    },
    "unknown_policy": {"on_unknown_event": "keep_event", "assign_action": "UNKNOWN", "report_to": "unknown_actions.csv", "blocking": True, "question_id": "Q_EVENT_MAP_001"},
}

HPREMATCH_RETRIEVAL_PROMPT_YAML = """hprematch_retrieval_prompt:
  name: "Hprematch Retrieval Prompt"
  version: "1.0"
  language: "tr"
""".strip()

METRIC_REGISTRY_CONTRACT_V2 = MetricRegistryContract(
    required_fields=["metric_id","name_tr","aliases","family","phase_allowed","layer","granularity","aggregation_type","unit","polarity","directionality","quality_flag"],
    pct_requires_dependencies=True,
)

INDEX_REGISTRY_CONTRACT_V2 = IndexRegistryContract(
    required_fields=["index_id","name_tr","family","phase","layer","allowed_granularity","normalization","inputs","gates","output_range","glossary","used_by_modules"],
)

UI_CONTRACT_V2 = UIContract(
    allowed_layers=["L2_scores","L3_explain","L4_scenarios","L_integrity","L_context"],
    forbidden_patterns=["raw_metrics_in_ui","raw_events_in_product_ui","heuristic_phase_in_ui"],
)

CARAVAGGIO_GRAPH_META_CONTRACT_V1 = CaravaggioGraphMetaContract(
    required_graph_meta_fields=["graph_id","what_question_does_this_answer","claim_sentence","phase_label","minute_window","score_state_layer","operational_definition","comparison_baseline","sample_size_n","units","failure_modes","counterexample_hook","view_type"],
    forbidden_patterns=["beauty_charts","phase-less average maps as evidence","single_metric ranking as publishable proof"],
    marker_contract_fixed={"Shot":"8","Pass":".","Carry":"p"}
)

HP_SYSTEM = HPSystemDefinition(
    name="HP System",
    mission="Sportsbase verisini canonical->map->validate->index->export hattına sokmak (NO-GUESSING).",
    non_negotiables=["NO-GUESSING","UNKNOWN=>STOP","Gate-driven","UI contract-driven","Core JSON-only"],
    layers={"core":["read_any","field_rename","map_metrics","validate_health","build_indices","emit_truth_artifacts"],"ui":["mapping_review + downloads"]},
    truth_artifacts=["mapped.parquet","indexbundle.json","coverage.json","questions_to_resolve.json","decisions.json"],
    default_gates={"min_coverage_ratio":0.97,"max_conflict_ratio":0.02,"max_unknown_ratio":0.0,"required_fields":["match_id","team_id","player_id","minute","event_type"],"fail_fast":True},
    assumptions=["Provider dictionary yoksa STOP + soru üret."],
    resolution_protocol=ResolutionProtocol(),
)

DECISIONS = [
    DecisionLock(id="D1", statement="Core JSON-only.", rationale="Determinism/test.", scope=["core","ui"]),
    DecisionLock(id="D2", statement="NO-GUESSING, unknown STOP + soru.", rationale="Sessiz yanlış yok.", scope=["core","validation","ui"]),
]

GATES = [
    GateRule(id="G_FIELD_UNKNOWN_STOP", description="Unknown field => STOP", applies_to=["core"], enforcement="fail_closed", error_code="UNKNOWN_FIELD", user_question_id="Q_FIELD_MAP_001"),
    GateRule(id="G_METRIC_UNKNOWN_STOP", description="Unknown metric => STOP", applies_to=["core"], enforcement="fail_closed", error_code="UNKNOWN_METRIC", user_question_id="Q_METRIC_MAP_001"),
]

RISKS = [
    RiskItem(id="R1", risk="Kolon adı değişir", failure_mode="mapping kayar", mitigation="Registry+STOP", owner_layer="core", severity="high"),
]

QUESTIONS_TEMPLATES = [
    ResolutionQuestion(
        id="Q_METRIC_MAP_001",
        subject="Bilinmeyen kolon hangi metric_id?",
        options=[{"action":"create_new_metric_id"},{"action":"bind_to_existing_metric_id"},{"action":"out_of_scope"}],
    )
]

ARTIFACTS = [
    ArtifactRef(name="metric_registry_v2.json", kind="registry", status="planned", purpose="Tek metric kanunu"),
]

def build_payload(patch_mode: bool = False) -> Dict[str, Any]:
    base = {
        "meta": {"id":"HP-SOT.v1.fixed","generated_at":_now_iso(),"hash":_sha16("HP-SOT.v1.fixed"),"patch_mode":patch_mode},
        "hp_system": asdict(HP_SYSTEM),
        "contracts": {
            "metric_registry_contract_v2": asdict(METRIC_REGISTRY_CONTRACT_V2),
            "index_registry_contract_v2": asdict(INDEX_REGISTRY_CONTRACT_V2),
            "ui_contract_v2": asdict(UI_CONTRACT_V2),
            "caravaggio_graph_meta_contract_v1": asdict(CARAVAGGIO_GRAPH_META_CONTRACT_V1),
        },
        "hp_spadl_event_map_v1": HP_SPADL_V1_EVENT_MAP,
        "retrieval_prompt_record": {"name":"Hprematch Retrieval Prompt","version":"1.0","language":"tr","yaml_text":HPREMATCH_RETRIEVAL_PROMPT_YAML},
        "decisions": [asdict(d) for d in DECISIONS],
        "gates": [asdict(g) for g in GATES],
        "risks": [asdict(r) for r in RISKS],
        "resolution_questions_templates": [asdict(q) for q in QUESTIONS_TEMPLATES],
        "artifacts": [asdict(a) for a in ARTIFACTS],
    }
    if patch_mode:
        return {"meta": base["meta"], "decisions": base["decisions"], "gates": base["gates"], "resolution_protocol": asdict(HP_SYSTEM.resolution_protocol)}
    return base

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--patch", action="store_true")
    args = ap.parse_args()
    print(_dump(build_payload(bool(args.patch))))

if __name__ == "__main__":
    main()
