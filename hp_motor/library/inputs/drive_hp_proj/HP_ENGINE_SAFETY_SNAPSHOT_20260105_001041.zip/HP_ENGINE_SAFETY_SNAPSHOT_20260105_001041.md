# HP ENGINE — SAFETY SNAPSHOT
Generated (UTC): 2026-01-05T00:10:41Z

Bu paket, HP Engine’in “yeniden baştan başlamadan” geri çağrılabilmesi için tek dosyalık kurtarma setidir.
Amaç: Bugüne kadar kilitlenen prensipleri, kararları ve çekirdek artefact’ları tek noktada saklamak.

---

## 1) Bu snapshot neyi garanti eder?
- **Scope / Foundation**: Analiz modülleri + veri mimarisi + Pre/Post match döngüsü + ontoloji + “hiçbir veriyi çöpe atmama”.
- **Fail-closed çalışma**: Veri belirsizse “tahmin yok”; sistem *UNKNOWN ⇒ STOP* prensibiyle ilerler.
- **Contamination savunması**: “Maç parmak izi (match fingerprint)” yaklaşımı ile yanlış dosya karışması analiz öncesi yakalanır.
- **Video pipeline taslağı**: Ingestion → tracking → homography → export hattı için karar fişi.

---

## 2) Operasyonel kısıtlar (kilit)
- Komutlar **Windows PowerShell** uyumlu olacak.
- “Yeni klasör açmadan bir iş yapılacaksa” **proje ana klasöründe** çalışılacak.

---

## 3) Bugün netleştirilen çekirdek fikirler
### 3.1 Post-Match otonom teşhis (hedef B)
Otonom sistem tanımı: veri alır → kendini kontrol eder → neyi analiz edebileceğine karar verir → kanıt üretir → teşhisi sınırlar → karar önerir → loglar.

### 3.2 Veri dosyaları birbirini desteklemeli
- Events: “Ne oldu?”
- Tracking: “Nerede/nasıl hareket?”
- Video: “Bağlam/kanıt”
Kesişim kümesi = izin verilen teşhis alanı.

### 3.3 “Yanlış dosya karışması” (contamination) riski
Çözüm: **Match Fingerprint**
- Tarih + takımlar + skor + kadro-hash (en güçlü)
- İçeriden doğrulama: süre/olay sayısı/entity sayısı gibi tutarlılık sinyalleri
- Set Integrity sonucu: PASS/WARN/FAIL (analizden önce)

### 3.4 Takım boyu/en ve blok boşlukları
- Event CSV tek başına (tek nokta olay konumu) **takım boyu/en** vermez.
- Takım boyu/en için tracking’de aynı anda tüm oyuncu pozisyonları + takım ayrımı gerekir.

---

## 4) DQ (Data Quality) gözlemi
Önceki çalışmada DQ raporu “FAIL” verdi:
- coverage_tracking = 0.0
- player_id_match_rate = 0.0
Sebep büyük olasılıkla şema uyumsuzluğu (ör: tracking header `Frame,Object,X,Y`).
Bu, “veri kötü” demek değil; “normalize edilmemiş” demek.

---

## 5) Bu paketin içindeki dosyalar (kanıtlı)
Aşağıdaki dosyalar bu zip’in içindedir ve SHA256 ile kimliklenmiştir:

[
  {
    "file": "SOHBET_FISI_HP_ENGINE_VIDEO_PIPELINE.md",
    "sha256": "6b0722cac53b3c97f2556c294cc5a633f6f8b1e24d1c07e73ba9aa7eab27dff4",
    "bytes": 2212,
    "modified_utc": "2026-01-05T00:09:51Z"
  },
  {
    "file": "hp_single_source_of_truth_v1_fixed.py",
    "sha256": "81c9076ac844a987b7e61512c0a613a3a3637a88926126627651a9d22fdb5860",
    "bytes": 11849,
    "modified_utc": "2026-01-05T00:09:51Z"
  },
  {
    "file": "HP_METRIC_NAMES_UNIQUE_v1.txt",
    "sha256": "0a03399eb0d10b688e59d2af6dcf6d9f5b12c7a30a5ea2da40e804fac98bb45e",
    "bytes": 9117,
    "modified_utc": "2026-01-05T00:09:52Z"
  },
  {
    "file": "Untitled0.ipynb",
    "sha256": "55b3ecd4b921c118d4724a99f8a15d3fea00c62e611fed7e83b1e0dd2f452a7a",
    "bytes": 293717,
    "modified_utc": "2026-01-05T00:09:53Z"
  },
  {
    "file": "Galatasaray 0-1 Union Saint-Gilloise 25.11.2025, Maçın Tamamı.csv",
    "sha256": "f3fddc0383bc06a2a6cefe162a31d3d5c70e5f3852b45eb028ca164f7eb871e1",
    "bytes": 458226,
    "modified_utc": "2026-01-05T00:09:52Z"
  }
]

---

## 6) Telefon-odaklı kurtarma kullanımı
Bu zip’i telefonunda sakla. Bir aksaklık olduğunda:
1) Zip’i aç.
2) `MANIFEST.json` ile dosya listesini gör.
3) Çekirdek referans olarak:
   - `hp_single_source_of_truth_v1_fixed.py` → “tahmin yok / UNKNOWN ⇒ STOP”
   - `SOHBET_FISI_HP_ENGINE_VIDEO_PIPELINE.md` → video pipeline karar fişi
   - `HP_METRIC_NAMES_UNIQUE_v1.txt` → metrik sözlüğü ham kaynak
4) Gerekirse repo’ya geri yazmak için zip içeriğini PC’ye aktar.

---

## 7) Not: Bu pakete bilinçli olarak dahil edilmeyenler
- BrandBook (PDF/DOCX) bu sohbet scope’u dışındaydı (UI/brand dili).
- 3 satırlık export özeti (değer üretmiyor).

