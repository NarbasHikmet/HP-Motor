# HP Engine Origin Bundle (Machine-Friendly)

Bu paket, bu sayfada konuştuğumuz sistem davranışını (kural + karar + korelasyon) **tek kaynak** halinde dışarı verir.

## Dosyalar
- origin_spec.yaml: Bu sayfanın tüm kritik kararları (gate'ler, recipe'ler, modüller)
- origin_spec.schema.json: Yapıyı doğrulamak için minimal schema
- decision_matrix.csv: Format x gate x modül matrisi
- hp_engine_codegen.py: origin_spec'ten recipes.generated.yaml üretmek için kod şablonu

## Çekirdek (non-negotiable)
- Kadro teyitsiz → safe_mode (oyuncu kesinliği yok)
- Fitness yok → enerji modülleri otomatik kapanır
- Format → hangi modüller çalışır
