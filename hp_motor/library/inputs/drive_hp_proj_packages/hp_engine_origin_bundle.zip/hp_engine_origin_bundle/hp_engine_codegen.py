# hp_engine_codegen.py
# Purpose: Convert origin_spec.yaml into engine config (recipes.generated.yaml) and enforce gates.
# Integrate into HP-APP pipeline.

from __future__ import annotations
import yaml
from typing import Dict, Any

def load_origin(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def build_recipes(origin: Dict[str, Any]) -> Dict[str, Any]:
    hp = origin["hp_engine"]
    out = {"version": "0.3", "recipes": {}}
    for fmt, cfg in hp["format_recipes"].items():
        cond = cfg.get("conditional_modules", [])
        cond_ids = [m["module_id"] for m in cond]
        out["recipes"][fmt] = {
            "name": fmt,
            "bridges": cfg["bridges"],
            "modules": cfg.get("required_modules", []) + cond_ids,
            "require_fitness_for": [m["module_id"] for m in cond if m["module_id"] in ["energy_pulse","energy_leak","sprint_production"]],
            "require_squad_verified": (fmt != "simulated_commentary"),
            "output_blocks": cfg.get("output_blocks", []),
        }
    return out

def main():
    origin = load_origin("origin_spec.yaml")
    recipes = build_recipes(origin)
    with open("recipes.generated.yaml", "w", encoding="utf-8") as f:
        yaml.safe_dump(recipes, f, sort_keys=False, allow_unicode=True)

if __name__ == "__main__":
    main()
