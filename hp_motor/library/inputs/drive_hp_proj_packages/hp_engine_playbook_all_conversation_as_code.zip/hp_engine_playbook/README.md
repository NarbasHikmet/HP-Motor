# HP Engine Playbook (Conversation -> Code)

This repo encodes our conversation into machine-friendly assets:

- manifest/hp_engine_manifest.yaml
- prompts/system_prompt_templates.yaml
- schema/hp_cdl_dictionary_v1.schema.json
- hp_engine_playbook/protocols.py (all protocols)
- tools/run_dictionary_pipeline.py (local runner)

Key decisions encoded:
- Triangular validation mandatory for claims.
- HP-ACM∞: mapped non-raw metrics must have >=1 alt_view (auto-filled if missing).
- Fitness metrics require match + individual + opponent integration.
- Dual-reading metrics exist (blocked shots, corners, aerial duels).
