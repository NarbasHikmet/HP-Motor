from __future__ import annotations
import argparse, json
from hp_engine_playbook.protocols import (
    metrics_from_dictionary_json, build_alias_map, validate_dictionary,
    build_test_report, map_headers
)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dict", required=True, help="Path to HP dictionary JSON (metrics list)")
    ap.add_argument("--headers", default="", help="Comma-separated headers to test mapping")
    ap.add_argument("--out", default="hp_report.json", help="Output report path")
    args = ap.parse_args()

    metrics = metrics_from_dictionary_json(args.dict, auto_fill_alt_views=True)
    alias_map, collisions = build_alias_map(metrics)
    v_errs = validate_dictionary(metrics)

    mapped_count = None
    unknown = None
    if args.headers.strip():
        headers = [h.strip() for h in args.headers.split(",") if h.strip()]
        mapped, unknown = map_headers(headers, alias_map)
        mapped_count = len(mapped)

    report = build_test_report(
        metrics,
        alias_collisions=collisions,
        validation_errors=v_errs,
        unknown_headers=unknown,
        mapped_headers_count=mapped_count,
    )
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print("Wrote:", args.out)

if __name__ == "__main__":
    main()
