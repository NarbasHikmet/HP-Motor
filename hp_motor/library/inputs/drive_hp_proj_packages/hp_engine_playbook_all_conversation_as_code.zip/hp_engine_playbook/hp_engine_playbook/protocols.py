from __future__ import annotations
import json, re
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple, Literal

Unit = Literal["count","pct","rate","meters","seconds","index","unknown"]
Polarity = Literal["higher_is_better","lower_is_better","contextual"]
Family = Literal[
    "contextual","circulation","progression","threat_creation","chance_quality","finalization",
    "defensive_reaction","defensive_organization","set_piece","goalkeeping","discipline",
    "fitness_capacity","fitness_intensity","load_recovery","medical_readiness","training","raw",
]
Phase = Literal["F0","F1","F2","F3","F4","F5","F6"]
Level = Literal["team","unit","player","unknown"]
Status = Literal["mapped","mapped_partial","raw_known_unit","raw_unknown"]
Vertex = Literal["data","tactical","psychodynamic"]

TACTICAL_FAMILIES = {
    "circulation","progression","threat_creation","chance_quality","finalization",
    "defensive_reaction","defensive_organization","set_piece","goalkeeping",
    "discipline","fitness_capacity","fitness_intensity","load_recovery",
    "medical_readiness","training"
}

@dataclass
class AlternativeView:
    title: str
    description: str
    pair_with: List[str] = field(default_factory=list)

@dataclass
class Metric:
    metric_id: str
    name: str
    universal_definition: str
    hp_definition: Optional[str]
    unit: Unit
    polarity: Polarity
    families: List[Family]
    phases: List[Phase]
    analysis_level: Level = "unknown"
    status: Status = "mapped_partial"
    aliases: List[str] = field(default_factory=list)
    video_tags: List[str] = field(default_factory=list)
    alt_views: List[AlternativeView] = field(default_factory=list)

    def is_hp_complete(self) -> bool:
        return bool(self.hp_definition and self.hp_definition.strip())

    def is_mapped(self) -> bool:
        return self.status in ("mapped","mapped_partial")

    def is_raw(self) -> bool:
        return ("raw" in self.families) or (self.status in ("raw_known_unit","raw_unknown"))

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["alt_views"] = [asdict(av) for av in self.alt_views]
        return d

def norm_header(s: str) -> str:
    s = str(s).strip().lower()
    s = s.replace("—","-").replace("–","-")
    s = re.sub(r"\s+"," ", s)
    s = re.sub(r"[^\w\s\-\.\%/]", "", s)
    return s

def build_alias_map(metrics: List[Metric]) -> Tuple[Dict[str,str], List[Tuple[str,str,str]]]:
    alias_map: Dict[str,str] = {}
    collisions: List[Tuple[str,str,str]] = []
    for m in metrics:
        keys = [m.name] + list(m.aliases or [])
        for k in keys:
            nk = norm_header(k)
            if not nk:
                continue
            if nk in alias_map and alias_map[nk] != m.metric_id:
                collisions.append((k, alias_map[nk], m.metric_id))
            else:
                alias_map[nk] = m.metric_id
    return alias_map, collisions

def map_headers(headers: List[str], alias_map: Dict[str,str]) -> Tuple[Dict[str,str], List[str]]:
    mapped: Dict[str,str] = {}
    unknown: List[str] = []
    for h in headers:
        mid = alias_map.get(norm_header(h))
        if mid:
            mapped[h] = mid
        else:
            unknown.append(h)
    return mapped, unknown

def suggest_default_alt_views(metric: Metric) -> List[AlternativeView]:
    fams = set(metric.families or [])
    out: List[AlternativeView] = []
    if "finalization" in fams:
        out.append(AlternativeView(
            title="Böyle de bak: Bitiriş mi, kaleci mi?",
            description="Sonuç zayıfsa bitiriş kalitesi veya kaleci etkisi ayrıştırılmalı.",
            pair_with=["goal_total","shot_on_target","xg"]
        ))
    if "progression" in fams or "threat_creation" in fams:
        out.append(AlternativeView(
            title="Böyle de bak: Cesaret mi, panik mi?",
            description="İlerleme artarken top kaybı da artıyorsa baskı/panik veya risk iştahı ayrıştırılmalı.",
            pair_with=["turnover_total","pressures","loss_balls"]
        ))
    if "fitness_intensity" in fams or "fitness_capacity" in fams:
        out.append(AlternativeView(
            title="Böyle de bak: Bedel mi, üstünlük mü?",
            description="Yük artışı avantaj üretmüyor olabilir; telafi koşuları artmış olabilir.",
            pair_with=["ball_recoveries","counter_attack_against","turnover_total"]
        ))
    if not out:
        out.append(AlternativeView(
            title="Böyle de bak: Bağlam penceresi",
            description="Skor-dakika-rakip planı metrik anlamını tersine çevirebilir.",
            pair_with=["score_state","minute_band","opponent_style_tag"]
        ))
    return out

def enforce_hp_acm_infinity(metric: Metric) -> List[str]:
    if metric.is_raw():
        return []
    if not metric.alt_views:
        return [f"HP-ACM∞ violation: '{metric.metric_id}' has no alt_views."]
    return []

def metrics_from_dictionary_json(path: str, *, auto_fill_alt_views: bool=True) -> List[Metric]:
    with open(path, "r", encoding="utf-8") as f:
        d = json.load(f)
    if not isinstance(d, dict) or not isinstance(d.get("metrics"), list):
        raise ValueError("Dictionary JSON must contain top-level 'metrics' list.")
    out: List[Metric] = []
    for m in d["metrics"]:
        alt_views = [AlternativeView(**av) for av in (m.get("alt_views") or [])]
        metric = Metric(
            metric_id=m["metric_id"],
            name=m["name"],
            universal_definition=m["universal_definition"],
            hp_definition=m.get("hp_definition"),
            unit=m.get("unit","unknown"),
            polarity=m.get("polarity","contextual"),
            families=m.get("families", ["raw"]),
            phases=m.get("phases", ["F0"]),
            analysis_level=m.get("analysis_level","unknown"),
            status=m.get("status","mapped_partial"),
            aliases=m.get("aliases", []),
            video_tags=m.get("video_tags", []),
            alt_views=alt_views,
        )
        if auto_fill_alt_views and metric.is_mapped() and (not metric.is_raw()) and (not metric.alt_views):
            metric.alt_views = suggest_default_alt_views(metric)
        out.append(metric)
    return out

def validate_dictionary(metrics: List[Metric]) -> List[str]:
    errs: List[str] = []
    for m in metrics:
        if not m.metric_id:
            errs.append("metric_id empty")
        if not m.name:
            errs.append(f"{m.metric_id}: name empty")
        if not (m.universal_definition and m.universal_definition.strip()):
            errs.append(f"{m.metric_id}: universal_definition empty")
        if not m.families:
            errs.append(f"{m.metric_id}: families empty")
        if not m.phases:
            errs.append(f"{m.metric_id}: phases empty")
        errs.extend(enforce_hp_acm_infinity(m))
    return errs

def metric_supported_vertices(metric: Metric) -> List[Vertex]:
    vertices: List[Vertex] = []
    if metric.universal_definition and metric.universal_definition.strip():
        vertices.append("data")
    has_tactical_family = any(f in TACTICAL_FAMILIES for f in (metric.families or []))
    has_phase_signal = bool(metric.phases) and not (len(metric.phases)==1 and metric.phases[0]=="F0")
    if has_tactical_family and (has_phase_signal or metric.analysis_level in ("team","unit")):
        vertices.append("tactical")
    if metric.video_tags:
        vertices.append("psychodynamic")
    out: List[Vertex] = []
    for v in ("data","tactical","psychodynamic"):
        if v in vertices:
            out.append(v)
    return out

def triangular_confidence(vertices_present: List[Vertex]) -> Dict[str, Any]:
    s = set(vertices_present)
    if len(s) <= 1:
        return {"level":"low","supported":sorted(s)}
    if len(s) == 2:
        return {"level":"medium","supported":sorted(s)}
    return {"level":"high","supported":sorted(s)}

def recommend_pairs(metrics: List[Metric], *, max_per_metric: int=5) -> Dict[str, List[str]]:
    out: Dict[str, List[str]] = {}
    for m in metrics:
        pairs: List[str] = []
        for av in (m.alt_views or []):
            for p in (av.pair_with or []):
                if p not in pairs:
                    pairs.append(p)
        if not pairs:
            fams = set(m.families or [])
            if "finalization" in fams:
                pairs = ["xg","shot_on_target","goal_total"]
            elif "progression" in fams:
                pairs = ["turnover_total","pressures","pass_into_final_third"]
            elif "fitness_intensity" in fams or "fitness_capacity" in fams:
                pairs = ["turnover_total","counter_attack_against","ball_recoveries"]
            else:
                pairs = ["score_state","minute_band"]
        out[m.metric_id] = pairs[:max_per_metric]
    return out

def build_test_report(
    metrics: List[Metric],
    *,
    alias_collisions: List[Tuple[str,str,str]],
    validation_errors: List[str],
    unknown_headers: Optional[List[str]] = None,
    mapped_headers_count: Optional[int] = None,
) -> Dict[str, Any]:
    total = len(metrics)
    hp_complete = sum(1 for m in metrics if m.is_hp_complete())
    raw_count = sum(1 for m in metrics if m.is_raw())
    mapped_count = sum(1 for m in metrics if m.is_mapped())
    acm_ok = sum(1 for m in metrics if (m.is_raw() or (m.alt_views and len(m.alt_views) > 0)))

    report: Dict[str, Any] = {
        "schema": "hp_engine_test_report_v1",
        "metrics": {
            "total_metrics": total,
            "hp_complete_count": hp_complete,
            "hp_missing_count": total - hp_complete,
            "raw_count": raw_count,
            "mapped_count": mapped_count,
            "acm_ok_count": acm_ok,
            "acm_missing_count": total - acm_ok,
        },
        "tests": {
            "alias_collision_check": {
                "pass": len(alias_collisions) == 0,
                "collisions_count": len(alias_collisions),
                "collisions": alias_collisions[:200],
            },
            "dictionary_validation_check": {
                "pass": len(validation_errors) == 0,
                "errors_count": len(validation_errors),
                "errors": validation_errors[:200],
            },
        },
    }
    if unknown_headers is not None or mapped_headers_count is not None:
        report["mapping"] = {
            "mapped_headers_count": int(mapped_headers_count or 0),
            "unknown_headers_count": len(unknown_headers or []),
            "unknown_headers": (unknown_headers or [])[:200],
        }
    return report

def build_alias_patch(manual_map: Dict[str,str]) -> Dict[str, Any]:
    ops = []
    for raw_header, metric_id in manual_map.items():
        ops.append({"op":"add_alias","metric_id":metric_id,"alias":raw_header,"reason":"manual mapping from ingestion UI"})
    return {"schema":"hp_cdl_patch_v1","ops": ops}
