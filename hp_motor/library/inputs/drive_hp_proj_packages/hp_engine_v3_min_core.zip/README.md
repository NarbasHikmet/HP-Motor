# HP Engine v3 - Minimal Core (PPDA + Field Tilt)

This is a *working* contract-first backbone:
- SportsBase-like provider mapping -> canonical events
- SOT validator that **reports** (no silent drop)
- Registry-driven MetricEngine
- Minimal PopperGate (claim status + confidence heuristic)
- PlotSpecFactory (no rendering; UI responsibility)
- AureliaNarrative (talk few, show limitations)

## Quick start
```bash
pip install -r requirements.txt
python demo/run_match.py
```

Place your SportsBase event export next to this folder and name it `Maçın Tamamı.csv` (or edit demo path).

## Output
A JSON blob containing:
- provider_mapping
- validation_report
- metrics (values + meta)
- claims (VERIFIED/DEGRADED/BLOCKED)
- plotspecs
- narrative
