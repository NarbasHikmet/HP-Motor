# HP Engine Contracts Pack (Generated 2026-01-20)

Contains JSON Schemas in `schemas/` and minimal examples in `examples/`.
