"""
Football Metrics Encyclopedia - Python Interface
HP Engine v24.0 - Hikmet Pınarbaşı
"""

import json

class MetricOntology:
    def __init__(self, json_path="metric_ontology.json"):
        with open(json_path, 'r', encoding='utf-8') as f:
            self.data = json.load(f)
        self.families = self.data['canonical_families']
    
    def get_metric(self, canonical_id):
        """Metrik bilgisini getir"""
        return self.families.get(canonical_id)
    
    def search(self, query):
        """Metrik ara (isim veya Türkçe)"""
        results = []
        query = query.lower()
        for id, metric in self.families.items():
            if (query in metric['name'].lower() or 
                query in metric.get('turkish', '').lower()):
                results.append({id: metric})
        return results
    
    def get_combination(self, metric_id):
        """Metrik kombinasyonlarını getir"""
        metric = self.get_metric(metric_id)
        return metric.get('combination') if metric else None

# Kullanım örneği
if __name__ == "__main__":
    ont = MetricOntology()
    
    # xG ara
    xg = ont.get_metric('expected_goals')
    print(f"Metrik: {xg['name']} ({xg['turkish']})")
    print(f"Platformlar: {list(xg['platforms'].keys())}")
    
    # Kombinasyon
    combo = ont.get_combination('post_shot_xg')
    print(f"\nKombinasyon: {combo}")
