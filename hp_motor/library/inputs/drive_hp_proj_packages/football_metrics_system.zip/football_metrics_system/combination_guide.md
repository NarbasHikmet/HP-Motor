# Futbol Metrikleri Birleştirme Kılavuzu

## 1. Bitiricilik Analizi
**Metrikler:** PSxG + xG  
**Formül:** SGA = PSxG - xG  
**Soru:** Forvet teknik mi, pozisyon ustası mı?  
**Grafik:** Scatter (xG/şut vs SGA)

## 2. Kaleci Performansı
**Metrikler:** PSxG Faced + Goals Conceded  
**Formül:** PSxG+/- = PSxG Faced - Goals  
**Soru:** Kaleci takımdan bağımsız ne kadar iyi?

## 3. Baskı Etkinliği
**Metrikler:** PPDA + BDP + Recovery Height  
**Formül:** BDP = (Expected Pass % - Actual Pass %) / Expected  
**Soru:** Baskımız verimli mi?

## 4. Top İlerleme
**Metrikler:** Progressive Passes + xT + Final 3rd Carries  
**Formül:** Prog Score = (Prog×3) + (F3rd×2) + (Box×4)  
**Soru:** Topu tehlikeli alanlara ne kadar iyi taşıyor?

## 5. Toplam Hücum Katkısı
**Metrikler:** npxG + xA  
**Formül:** npxG+xA per 90  
**Soru:** Toplam beklenen hücum katkısı?

## 6. Yaratıcılık Kalitesi
**Metrikler:** xA + Actual Assists  
**Formül:** Creative Diff = Assists - xA  
**Soru:** Asistler gerçek yaratıcılığı mı yansıtıyor?

## 7. Fiziksel Patlayıcılık
**Metrikler:** HSR + Sprints + Accelerations  
**Formül:** Explosive Index = (HSR + Sprint×0.1 + Acc×0.05) / 90  
**Soru:** Patlayıcı fiziksel çıktı ne kadar?

## 8. Savunma Dominansı
**Metrikler:** Aerials + Interceptions + Clearances  
**Formül:** Def Impact = (Aerial%×2) + Int/90 + Clear/90  
**Soru:** Stoper hem havada hem yerde baskın mı?

## 9. Baskı Sonrası Kazanım
**Metrikler:** PPDA + High Turnovers + Recovery Height  
**Formül:** Press-Recovery = (HT × Rec Height) / PPDA  
**Soru:** Baskı sonrası topu nerede kazanıyoruz?

## 10. Alan Penetrasyonu
**Metrikler:** Deep Completions + xG from DC + Shots from DC  
**Formül:** DC Efficiency = xG from deep / DC  
**Soru:** Ceza alanı pasları ne kadar kaliteli?
