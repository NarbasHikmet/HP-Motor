# Futbol Metrikleri Konsolidasyon Sistemi v1.0

Bu sistem 8 major platform üzerinden 187 metriği 47 canonical family altında konsolide eder.

## Dosyalar
- `metric_ontology.json` - Core families
- `platform_mappings.json` - Platform translation
- `combination_guide.md` - Türkçe birleştirme kılavuzu

## Hızlı Başlangıç

### Platform Çevirme
Wyscout "xG" → Canonical "Expected Goals"

### Metrik Birleştirme
PSxG - xG = Finishing Skill (combination_guide.md #1)

### HP Engine Mapping
PPDA → Categories: Pre-Match, Tactical
PPDA → Phases: Defensive Org, Attack→Defense

## Core 15 Metrik
1. xG - Expected Goals
2. PSxG - Post-Shot xG  
3. xA - Expected Assists
4. OBV/VAEP/xT - Possession Value
5. PPDA - Pressing Intensity
6. Prog - Progressive Passes
7. SCA/GCA - Shot-Creating Actions
8. DC - Deep Completion
9. Smart Pass - Line-breaking
10. Aerials/HOPS - Aerial Duels
11. Distance - Total running
12. HSR - High Intensity Running
13. Sprints - Max speed efforts
14. Off-Ball Runs - Movement without ball
15. Pitch Control - Space control

## Platform Özellikleri

**StatsBomb:** 360 freeze-frame, OBV, HOPS  
**Opta:** Industry standard, xGOT, biggest dataset  
**Wyscout:** 600+ leagues, Smart Pass, DC  
**FBref:** Free access, SCA/GCA  
**Understat:** Public xG model  
**SkillCorner:** Off-Ball Runs, tracking

## HP Engine 7 Kategorisi
1. Pre-Match Analysis
2. Post-Match Analysis  
3. Individual Analysis
4. Team Tactical Analysis
5. Seasonal & Tournament
6. Squad Engineering
7. General Analysis

## HP Engine 6 Fazı
1. Savunma Organizasyonu
2. Savunma→Hücum
3. Build-Up
4. Hücum Organizasyonu
5. Hücum→Savunma
6. Set Pieces

## HP Engine 3 Katmanı
- Mikro: Bireysel aksiyon
- Mezzo: Sekans/patern
- Makro: Takım/maç

## Konsolidasyon Kuralları

**Aynı Amaç, Farklı İsim:**  
Key Pass = Shot Assist = Final pass to shot

**Aynı İsim, Farklı Hesaplama:**  
Progressive Pass: Opta (25% closer) ≠ FBref (10+ yards) ≠ Wyscout (tiered)

**Platform-Exclusive:**  
OBV (StatsBomb only), Smart Pass (Wyscout only), Off-Ball Runs (SkillCorner only)

## Kullanım Senaryoları

**Forvet Transfer:** npxG + xA + SCA + (PSxG-xG)  
**Baskı Analizi:** PPDA + BDP + High Turnovers  
**Orta Saha:** Prog + xT + OBV + Pass %  
**Kaleci:** PSxG+/- + Save % + Distribution

## SSS

**S: xG neden farklı platformlarda farklı?**  
C: Farklı modeller (XGBoost vs Neural Net) + farklı features (360 vs location only)

**S: VAEP vs OBV vs xT?**  
C: xT=basit/açık, VAEP=akademik/151 feature, OBV=StatsBomb proprietary

**S: PPDA yanıltıcı olabilir mi?**  
C: Evet - yüksek possession = düşük PPDA (rakip az pas). Mutlaka BDP ile birleştir.

**S: Tracking data gerektiren metrikler?**  
C: Off-Ball Runs, Pitch Control, HSR, Sprints, Accelerations

---

**Yazar:** HP Engine Research  
**Sahip:** Hikmet Pınarbaşı  
**Tarih:** 2026-01-21  
**Versiyon:** 1.0
