from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Literal

MetricOutputType = Literal["float", "int", "bool", "str"]
ComputeFn = Callable[..., Any]


@dataclass(frozen=True)
class MetricOutput:
    name: str
    type: MetricOutputType
    range: tuple[float, float] | None = None


@dataclass(frozen=True)
class MetricSpec:
    metric_id: str
    version: str
    full_name: str
    description: str
    category: str | None = None
    subcategory: str | None = None
    aliases: list[str] = field(default_factory=list)
    provider_variant: str = "generic"

    required_fields: list[str] = field(default_factory=list)
    required_upstream_metrics: list[str] = field(default_factory=list)
    optional_fields: list[str] = field(default_factory=list)

    outputs: list[MetricOutput] = field(default_factory=list)

    impl_module: str = ""
    impl_function: str = ""

    derivation: dict[str, Any] = field(default_factory=dict)
    enables: dict[str, Any] = field(default_factory=dict)
    dimensions: dict[str, Any] = field(default_factory=dict)

    def key(self) -> str:
        return f"{self.metric_id}@{self.version}:{self.provider_variant}"
