from __future__ import annotations

import glob
import importlib
import os
from dataclasses import asdict
from typing import Dict, List

import yaml

from .types import MetricOutput, MetricSpec, ComputeFn


class MetricRegistry:
    def __init__(self) -> None:
        self._specs: Dict[str, MetricSpec] = {}
        self._fns: Dict[str, ComputeFn] = {}

    def register(self, spec: MetricSpec, fn: ComputeFn) -> None:
        key = spec.key()
        if key in self._specs:
            raise ValueError(f"Duplicate metric key: {key}")
        self._specs[key] = spec
        self._fns[key] = fn

    def list(self) -> List[str]:
        return sorted(self._specs.keys())

    def get_spec(self, key: str) -> MetricSpec:
        return self._specs[key]

    def get_fn(self, key: str) -> ComputeFn:
        return self._fns[key]

    def resolve(self, metric_id: str, version: str, provider_variant: str = "generic") -> str:
        key = f"{metric_id}@{version}:{provider_variant}"
        if key not in self._specs:
            raise KeyError(f"Unknown metric: {key}")
        return key

    def dump_specs(self) -> List[dict]:
        return [asdict(s) for s in self._specs.values()]


def _load_yaml(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def load_metric_specs(canon_metrics_dir: str) -> List[MetricSpec]:
    specs: List[MetricSpec] = []
    for path in sorted(glob.glob(os.path.join(canon_metrics_dir, "**/*.yaml"), recursive=True)):
        raw = _load_yaml(path)
        # minimal validation
        for k in ("metric_id", "version", "full_name", "description", "outputs", "data_requirements", "impl"):
            if k not in raw:
                raise ValueError(f"Spec missing '{k}': {path}")

        outs = []
        for o in raw["outputs"]:
            outs.append(MetricOutput(name=o["name"], type=o["type"], range=tuple(o.get("range")) if o.get("range") else None))

        dr = raw.get("data_requirements", {})
        impl = raw.get("impl", {})

        specs.append(
            MetricSpec(
                metric_id=raw["metric_id"],
                version=str(raw["version"]),
                full_name=raw["full_name"],
                description=raw["description"],
                category=raw.get("category"),
                subcategory=raw.get("subcategory"),
                aliases=raw.get("aliases", []) or [],
                provider_variant=raw.get("provider_variant", "generic"),
                required_fields=dr.get("required_fields", []) or [],
                required_upstream_metrics=dr.get("required_upstream_metrics", []) or [],
                optional_fields=dr.get("optional_fields", []) or [],
                outputs=outs,
                impl_module=impl.get("module", ""),
                impl_function=impl.get("function", ""),
                derivation=raw.get("derivation", {}) or {},
                enables=raw.get("enables", {}) or {},
                dimensions=raw.get("dimensions", {}) or {},
            )
        )
    return specs


def load_registry(canon_metrics_dir: str) -> MetricRegistry:
    reg = MetricRegistry()
    for spec in load_metric_specs(canon_metrics_dir):
        if not spec.impl_module or not spec.impl_function:
            raise ValueError(f"Metric {spec.key()} missing impl.module/function")
        mod = importlib.import_module(spec.impl_module)
        fn = getattr(mod, spec.impl_function)
        reg.register(spec, fn)
    return reg
