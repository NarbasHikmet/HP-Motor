from __future__ import annotations

import pandas as pd


def compute_ppda(
    actions: pd.DataFrame,
    defending_team: str,
    team_col: str = "team",
    action_col: str = "action",
    x_col: str = "pos_x",
    press_zone_max_x: float = 60.0,
) -> float:
    """Compute a basic PPDA (Passes Per Defensive Action) proxy.

    PPDA = opponent passes in press zone / defending_team defensive actions in same zone.

    This implementation is event-only and provider-agnostic; tune action mapping per provider.
    """
    if team_col not in actions.columns or action_col not in actions.columns:
        raise ValueError("actions must include team and action columns")

    df = actions.copy()
    if x_col in df.columns:
        df = df[df[x_col].astype(float) <= press_zone_max_x]

    opp = df[df[team_col] != defending_team]
    deff = df[df[team_col] == defending_team]

    passes = opp[opp[action_col].astype(str).str.lower().str.contains("pass")]

    # defensive actions: tackle, interception, foul, challenge, pressure, block
    defensive = deff[
        deff[action_col]
        .astype(str)
        .str.lower()
        .str.contains("tackle|interception|foul|challenge|pressure|block")
    ]

    denom = len(defensive)
    if denom == 0:
        return float("inf")
    return float(len(passes) / denom)
