from __future__ import annotations

import numpy as np
import pandas as pd

# MVP xT: static grid value increasing towards goal.
# Replace with learned transition/probability model for production.

GRID_X = 16
GRID_Y = 12

# heuristic: value increases with x (attacking direction) and centrally (y close to 50)
_x = np.linspace(0, 1, GRID_X, endpoint=False) + (1 / GRID_X) / 2
_y = np.linspace(0, 1, GRID_Y, endpoint=False) + (1 / GRID_Y) / 2
XV, YV = np.meshgrid(_x, _y)
CENTER = 0.5
XT_GRID = (XV ** 2.0) * (1.0 - 0.6 * np.abs(YV - CENTER))
XT_GRID = np.clip(XT_GRID, 0.0, None)


def _bin_xy(x: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    xb = np.clip((x / 100.0 * GRID_X).astype(int), 0, GRID_X - 1)
    yb = np.clip((y / 100.0 * GRID_Y).astype(int), 0, GRID_Y - 1)
    return xb, yb


def compute_xt(
    actions: pd.DataFrame,
    start_x: str = "pos_x",
    start_y: str = "pos_y",
    end_x: str = "end_x",
    end_y: str = "end_y",
    action_col: str = "action",
) -> pd.Series:
    """Compute xT added for passes/carries using a static grid.

    Required columns: pos_x,pos_y,end_x,end_y,action
    Output: xT_added series aligned with input index (0 for non-pass/carry or missing end coords).
    """
    out = np.zeros(len(actions), dtype=float)

    if start_x not in actions.columns or start_y not in actions.columns:
        return pd.Series(out, index=actions.index, name="xt_added")

    # end coords optional
    if end_x not in actions.columns or end_y not in actions.columns:
        return pd.Series(out, index=actions.index, name="xt_added")

    a = actions[action_col].astype(str).str.lower() if action_col in actions.columns else None
    mask = np.ones(len(actions), dtype=bool)
    if a is not None:
        mask = a.str.contains("pass|carry|dribble").to_numpy()

    sx = actions[start_x].to_numpy(dtype=float, copy=False)
    sy = actions[start_y].to_numpy(dtype=float, copy=False)
    ex = actions[end_x].to_numpy(dtype=float, copy=False)
    ey = actions[end_y].to_numpy(dtype=float, copy=False)

    xb0, yb0 = _bin_xy(sx, sy)
    xb1, yb1 = _bin_xy(ex, ey)

    v0 = XT_GRID[yb0, xb0]
    v1 = XT_GRID[yb1, xb1]
    delta = v1 - v0
    out[mask] = delta[mask]

    return pd.Series(out, index=actions.index, name="xt_added")
