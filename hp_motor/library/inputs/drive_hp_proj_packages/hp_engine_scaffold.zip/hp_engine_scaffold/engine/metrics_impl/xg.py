from __future__ import annotations

import numpy as np
import pandas as pd

# MVP baseline xG: distance+angle logistic. This is not provider-grade.
# Coordinates assumption: 0-100 both axes, attacking direction left->right, goal at (100,50).

def _shot_distance_angle(x: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    goal_x, goal_y = 100.0, 50.0
    dx = goal_x - x
    dy = np.abs(goal_y - y)
    dist = np.sqrt(dx * dx + dy * dy)

    # angle subtended by goal posts (approx in degrees)
    # posts at y=44 and y=56 in 0-100 scale (18yd box width approx). This is a heuristic.
    left_post_y, right_post_y = 44.0, 56.0
    a = np.arctan2(right_post_y - y, dx)
    b = np.arctan2(left_post_y - y, dx)
    ang = np.abs(a - b)  # radians
    ang_deg = ang * (180.0 / np.pi)
    return dist, ang_deg


def compute_xg(actions: pd.DataFrame, x_col: str = "pos_x", y_col: str = "pos_y") -> pd.Series:
    """Compute baseline xG for shot events.

    Required columns: pos_x, pos_y
    Output: xg series aligned with input index (0 for non-shots).
    """
    x = actions[x_col].to_numpy(dtype=float, copy=False)
    y = actions[y_col].to_numpy(dtype=float, copy=False)

    dist, ang = _shot_distance_angle(x, y)

    # coefficients tuned for plausible range; replace with fitted model later
    b0 = -1.5
    b_dist = -0.12
    b_ang = 0.06

    z = b0 + b_dist * dist + b_ang * ang
    p = 1.0 / (1.0 + np.exp(-z))

    # if action type exists, zero out non-shots
    if "action" in actions.columns:
        is_shot = actions["action"].astype(str).str.lower().str.contains("shot")
        p = np.where(is_shot.to_numpy(), p, 0.0)

    return pd.Series(p, index=actions.index, name="xg")
