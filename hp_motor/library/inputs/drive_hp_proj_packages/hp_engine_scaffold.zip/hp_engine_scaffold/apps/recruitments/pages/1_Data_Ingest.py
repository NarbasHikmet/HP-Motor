import streamlit as st
import pandas as pd
from pathlib import Path
from lxml import etree

st.set_page_config(layout="wide")
st.title("Data ingest & preview")

root = Path(__file__).resolve().parents[3]
data_dir = st.text_input("Data directory", value="/mnt/data")

files = sorted([p for p in Path(data_dir).iterdir() if p.is_file()])
choice = st.selectbox("Select file", options=[p.name for p in files])
path = Path(data_dir) / choice

st.write("Selected:", str(path))

suffix = path.suffix.lower()
if suffix == ".csv":
    df = pd.read_csv(path)
    st.dataframe(df, use_container_width=True, height=500)
elif suffix in {".xlsx", ".xls"}:
    xl = pd.ExcelFile(path)
    sheet = st.selectbox("Sheet", options=xl.sheet_names)
    df = xl.parse(sheet_name=sheet)
    st.dataframe(df, use_container_width=True, height=500)
elif suffix == ".xml":
    tree = etree.parse(str(path))
    root_el = tree.getroot()
    st.write("Root tag:", root_el.tag)
    st.write("Children:", len(root_el))
    # show first 50 tags
    tags = []
    for i, el in enumerate(root_el.iter()):
        tags.append(el.tag)
        if i > 50:
            break
    st.code("\n".join(tags))
else:
    st.info("Preview not implemented for this file type in MVP.")
