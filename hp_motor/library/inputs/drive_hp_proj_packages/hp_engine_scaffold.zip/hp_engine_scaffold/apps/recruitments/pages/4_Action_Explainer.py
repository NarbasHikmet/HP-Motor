import streamlit as st
import pandas as pd
from pathlib import Path

from engine.metrics.registry import load_registry

st.set_page_config(layout="wide")
st.title("Action explainer (multi-dimensional) — MVP")

root = Path(__file__).resolve().parents[3]
canon_metrics_dir = root / "canon" / "metrics" / "spec"
reg = load_registry(str(canon_metrics_dir))

data_dir = st.text_input("Data directory", value="/mnt/data")

csv_files = sorted([p for p in Path(data_dir).iterdir() if p.is_file() and p.suffix.lower() == ".csv"])
if not csv_files:
    st.info("No CSV found in the selected directory.")
    st.stop()

f = st.selectbox("Match CSV", options=[p.name for p in csv_files])
path = Path(data_dir) / f

sep = st.selectbox("CSV delimiter", options=[";", ",", "\t"], index=0)
df = pd.read_csv(path, sep=sep)

st.write("Rows", len(df), "Cols", len(df.columns))

# basic cleanup
for c in ["pos_x", "pos_y"]:
    if c in df.columns:
        df[c] = pd.to_numeric(df[c], errors="coerce")

if "start" in df.columns:
    df["minute"] = pd.to_numeric(df["start"], errors="coerce") / 60.0

# pick action
idx = st.number_input("Row index", min_value=0, max_value=max(0, len(df) - 1), value=0, step=1)
row = df.iloc[int(idx)]

col1, col2 = st.columns([1, 1])
with col1:
    st.subheader("Raw action")
    st.json(row.fillna("").to_dict())
with col2:
    st.subheader("Computed core metrics")
    # xG
    try:
        xg_key = reg.resolve("xg", "1.0.0")
        xg_fn = reg.get_fn(xg_key)
        xg = float(xg_fn(df.iloc[[int(idx)]])["xg"].iloc[0])
    except Exception as e:
        xg = None
        st.write("xG error:", str(e))

    # xT
    try:
        xt_key = reg.resolve("xt", "1.0.0")
        xt_fn = reg.get_fn(xt_key)
        xt = float(xt_fn(df.iloc[[int(idx)]])["xt_added"].iloc[0])
    except Exception:
        xt = None

    st.metric("xG", "-" if xg is None else f"{xg:.3f}")
    st.metric("xT_added", "-" if xt is None else f"{xt:.3f}")

st.divider()

st.subheader("Multi-dimensional explanation")

# Tactical: action type + zone
action = str(row.get("action", ""))
team = str(row.get("team", ""))
minute = row.get("minute", None)
x = row.get("pos_x", None)
y = row.get("pos_y", None)

bullets = []

if xg is not None:
    label = "zor" if xg < 0.10 else "orta" if xg < 0.20 else "iyi"
    bullets.append(f"**xG:** {xg:.2f} ({label} şut / bitiriş olasılığı)")
else:
    bullets.append("**xG:** hesaplanamadı (pos_x/pos_y veya action mapping eksik)")

if minute is not None and pd.notna(minute):
    bullets.append(f"**Context:** {minute:.1f}. dakika")

if x is not None and pd.notna(x) and y is not None and pd.notna(y):
    corridor = "sağ" if y > 66 else "sol" if y < 33 else "merkez"
    bullets.append(f"**Tactical/Space:** {corridor} koridor, (x={x:.1f}, y={y:.1f})")

bullets.append("**Physical:** bu sayfa MVP — fitness sheet bağlanınca fatigue index + HSR/MP ile doldurulacak")
bullets.append("**Psychological/Mental:** proxy — skor durumu + maç önemi + risk seçimi ile (confidence ile) eklenecek")
bullets.append("**Neurological:** tracking/video varsa decision-time (top kontrol → aksiyon) ölçülecek")

for b in bullets:
    st.markdown(f"- {b}")

st.info("Bu explain çıktısı 'kanıt + belirsizlik' disiplinine göre büyütülecek: her boyut için evidence + confidence.")
