import streamlit as st
from pathlib import Path

st.set_page_config(page_title="HP Recruitments", layout="wide")

st.title("HP Recruitments")
st.caption("Data → Signals → Metrics → Constructs. Minimal scaffold.")

root = Path(__file__).resolve().parents[2]
canon_dir = root / "canon"
engine_dir = root / "engine"

def _exists(p: Path) -> str:
    return "✅" if p.exists() else "❌"

col1, col2, col3 = st.columns(3)
with col1:
    st.subheader("Canon")
    st.write("metrics/spec", _exists(canon_dir / "metrics" / "spec"))
    st.write("signals", _exists(canon_dir / "signals"))
with col2:
    st.subheader("Engine")
    st.write("metrics", _exists(engine_dir / "metrics"))
    st.write("ontology", _exists(engine_dir / "ontology"))
with col3:
    st.subheader("Tools")
    st.write("build_signal_inventory.py", _exists(root / "tools" / "build_signal_inventory.py"))
    st.write("build_metric_graph.py", _exists(root / "tools" / "build_metric_graph.py"))

st.divider()

st.markdown(
    """
What you can do next:
- **Signals**: run `python tools/build_signal_inventory.py --data_dir /path/to/data --out canon/signals/auto_inventory.yaml`
- **Metrics**: add specs under `canon/metrics/spec` and implementations under `engine/metrics_impl`
- **Ontology**: run `python tools/build_metric_graph.py` to export graph

Use the pages on the left to inspect inventory, registry, and explain actions.
"""
)
