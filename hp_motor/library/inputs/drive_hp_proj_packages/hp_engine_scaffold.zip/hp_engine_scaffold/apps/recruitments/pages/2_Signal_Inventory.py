import streamlit as st
import pandas as pd
import yaml
from pathlib import Path

st.set_page_config(layout="wide")
st.title("Signal inventory")

root = Path(__file__).resolve().parents[3]
inv_path = root / "canon" / "signals" / "auto_inventory.yaml"

st.write("Inventory file:", str(inv_path))
if not inv_path.exists():
    st.warning("auto_inventory.yaml not found. Run: python tools/build_signal_inventory.py")
    st.stop()

with open(inv_path, "r", encoding="utf-8") as f:
    payload = yaml.safe_load(f)

signals = payload.get("signals", [])
df = pd.DataFrame(signals)

st.metric("Signals", len(df))

q = st.text_input("Filter (substring in signal_id)")
if q:
    df = df[df["signal_id"].str.contains(q, case=False, na=False)]

kind = st.multiselect("Kind", options=sorted(df["kind"].unique().tolist()), default=sorted(df["kind"].unique().tolist()))
df = df[df["kind"].isin(kind)]

st.dataframe(df, use_container_width=True, height=560)

st.divider()
st.subheader("Coverage quick view")
# show most frequent sources
src_counts = (
    df.explode("sources")
      .groupby("sources")
      .size()
      .sort_values(ascending=False)
      .head(30)
)
st.bar_chart(src_counts)
