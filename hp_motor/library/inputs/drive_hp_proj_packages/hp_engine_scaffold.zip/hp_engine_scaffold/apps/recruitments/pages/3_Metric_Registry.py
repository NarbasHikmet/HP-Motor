import streamlit as st
import pandas as pd
from pathlib import Path

from engine.metrics.registry import load_registry

st.set_page_config(layout="wide")
st.title("Metric registry")

root = Path(__file__).resolve().parents[3]
canon_metrics_dir = root / "canon" / "metrics" / "spec"

reg = load_registry(str(canon_metrics_dir))
keys = reg.list()

st.metric("Registered metrics", len(keys))

sel = st.selectbox("Select metric", options=keys)
spec = reg.get_spec(sel)

col1, col2 = st.columns([2,1])
with col1:
    st.subheader("Spec")
    st.json({
        "metric_id": spec.metric_id,
        "version": spec.version,
        "provider_variant": spec.provider_variant,
        "full_name": spec.full_name,
        "description": spec.description,
        "category": spec.category,
        "subcategory": spec.subcategory,
        "aliases": spec.aliases,
        "required_fields": spec.required_fields,
        "required_upstream_metrics": spec.required_upstream_metrics,
        "outputs": [o.__dict__ for o in spec.outputs],
        "derivation": spec.derivation,
        "enables": spec.enables,
        "dimensions": spec.dimensions,
        "impl": {"module": spec.impl_module, "function": spec.impl_function},
    })
with col2:
    st.subheader("Quick checks")
    st.write("Impl import", "✅")

st.divider()
st.subheader("All metrics")
rows = []
for k in keys:
    s = reg.get_spec(k)
    rows.append({
        "key": k,
        "metric_id": s.metric_id,
        "version": s.version,
        "category": s.category,
        "subcategory": s.subcategory,
    })

df = pd.DataFrame(rows)
st.dataframe(df, use_container_width=True, height=380)
