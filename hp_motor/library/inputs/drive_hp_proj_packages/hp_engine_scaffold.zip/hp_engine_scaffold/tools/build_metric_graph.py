from __future__ import annotations

import os
from pathlib import Path

import networkx as nx
import yaml


def load_specs(canon_metrics_dir: str) -> list[dict]:
    specs = []
    for p in sorted(Path(canon_metrics_dir).rglob("*.yaml")):
        with open(p, "r", encoding="utf-8") as f:
            specs.append(yaml.safe_load(f))
    return specs


def build_graph(specs: list[dict]) -> nx.DiGraph:
    G = nx.DiGraph()
    for s in specs:
        mid = f"{s['metric_id']}@{s['version']}:{s.get('provider_variant','generic')}"
        G.add_node(mid, **{
            "metric_id": s["metric_id"],
            "version": str(s["version"]),
            "category": s.get("category"),
            "subcategory": s.get("subcategory"),
        })

    # derivation edges: upstream metrics -> metric
    for s in specs:
        mid = f"{s['metric_id']}@{s['version']}:{s.get('provider_variant','generic')}"
        req = (s.get("data_requirements") or {}).get("required_upstream_metrics") or []
        for up in req:
            # up may omit version; allow fuzzy node
            for n in list(G.nodes):
                if n.startswith(f"{up}@"):
                    G.add_edge(n, mid, relation="derives")

        # enables edges: metric -> downstream
        for d in (s.get("enables") or {}).get("downstream") or []:
            did = d.get("metric_id")
            if not did:
                continue
            # connect to any node with did
            for n in list(G.nodes):
                if n.startswith(f"{did}@"):
                    G.add_edge(mid, n, relation="enables")

    return G


def main(canon_metrics_dir: str, out_graphml: str, out_json: str) -> None:
    specs = load_specs(canon_metrics_dir)
    G = build_graph(specs)
    nx.write_graphml(G, out_graphml)

    data = {
        "nodes": [{"id": n, **G.nodes[n]} for n in G.nodes],
        "edges": [{"source": u, "target": v, **G.edges[u, v]} for u, v in G.edges],
    }
    with open(out_json, "w", encoding="utf-8") as f:
        yaml.safe_dump(data, f, sort_keys=False, allow_unicode=True)


if __name__ == "__main__":
    import argparse

    ap = argparse.ArgumentParser()
    ap.add_argument("--canon_metrics_dir", default="canon/metrics/spec")
    ap.add_argument("--out_graphml", default="engine/ontology/metric_graph.graphml")
    ap.add_argument("--out_json", default="engine/ontology/metric_graph.yaml")
    args = ap.parse_args()

    main(args.canon_metrics_dir, args.out_graphml, args.out_json)
