from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

import pandas as pd
from lxml import etree
import yaml

SUPPORTED_EXT = {".csv", ".xlsx", ".xls", ".xml"}

@dataclass
class Signal:
    signal_id: str
    kind: str  # raw_column | xml_field
    dtype: str | None
    sources: list[str]


def _norm(s: str) -> str:
    s = s.strip()
    s = re.sub(r"\s+", "_", s)
    s = re.sub(r"[^0-9a-zA-Z_]+", "", s)
    return s.lower()


def extract_from_csv(path: Path) -> list[Signal]:
    df = pd.read_csv(path, nrows=200)
    out: list[Signal] = []
    for c in df.columns:
        sid = _norm(c)
        dtype = str(df[c].dtype)
        out.append(Signal(signal_id=sid, kind="raw_column", dtype=dtype, sources=[path.name]))
    return out


def extract_from_xlsx(path: Path) -> list[Signal]:
    xl = pd.ExcelFile(path)
    out: list[Signal] = []
    for sheet in xl.sheet_names:
        df = xl.parse(sheet_name=sheet, nrows=200)
        for c in df.columns:
            sid = _norm(str(c))
            dtype = str(df[c].dtype)
            out.append(Signal(signal_id=sid, kind="raw_column", dtype=dtype, sources=[f"{path.name}::{sheet}"]))
    return out


def extract_from_xml(path: Path) -> list[Signal]:
    # light extraction: tag names + common attributes
    root = etree.parse(str(path)).getroot()
    tags = set()
    attrs = set()
    for el in root.iter():
        tags.add(el.tag.split("}")[-1])
        for k in el.attrib.keys():
            attrs.add(k)
    out: list[Signal] = []
    for t in sorted(tags):
        out.append(Signal(signal_id=_norm(f"xml_tag_{t}"), kind="xml_tag", dtype=None, sources=[path.name]))
    for a in sorted(attrs):
        out.append(Signal(signal_id=_norm(f"xml_attr_{a}"), kind="xml_attr", dtype=None, sources=[path.name]))
    return out


def merge(signals: list[Signal]) -> dict[str, Signal]:
    merged: dict[str, Signal] = {}
    for s in signals:
        if s.signal_id not in merged:
            merged[s.signal_id] = s
        else:
            m = merged[s.signal_id]
            m.sources = sorted(set(m.sources + s.sources))
            # keep kind/dtype as first occurrence
    return merged


def main(data_dir: str, out_yaml: str) -> None:
    data_path = Path(data_dir)
    all_sigs: list[Signal] = []

    for p in sorted(data_path.iterdir()):
        if p.is_dir():
            continue
        if p.suffix.lower() not in SUPPORTED_EXT:
            continue
        try:
            if p.suffix.lower() == ".csv":
                all_sigs.extend(extract_from_csv(p))
            elif p.suffix.lower() in {".xlsx", ".xls"}:
                all_sigs.extend(extract_from_xlsx(p))
            elif p.suffix.lower() == ".xml":
                all_sigs.extend(extract_from_xml(p))
        except Exception as e:
            # don't fail build; store error as meta
            all_sigs.append(Signal(signal_id=_norm(f"error_{p.stem}"), kind="error", dtype=str(e), sources=[p.name]))

    merged = merge(all_sigs)

    payload: dict[str, Any] = {
        "generated_from": str(data_path),
        "num_signals": len(merged),
        "signals": [asdict(s) for s in sorted(merged.values(), key=lambda x: x.signal_id)],
    }

    with open(out_yaml, "w", encoding="utf-8") as f:
        yaml.safe_dump(payload, f, sort_keys=False, allow_unicode=True)


if __name__ == "__main__":
    import argparse

    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", default="/mnt/data")
    ap.add_argument("--out", default="canon/signals/auto_inventory.yaml")
    args = ap.parse_args()

    main(args.data_dir, args.out)
