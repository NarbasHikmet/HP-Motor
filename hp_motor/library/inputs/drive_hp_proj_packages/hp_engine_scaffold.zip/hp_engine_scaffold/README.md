# HP Engine Scaffold (Canon + Registry + Ontology + Streamlit)

This scaffold implements:
- **Canon metric specs** (`canon/metrics/spec/*.yaml`)
- **Metric auto-discovery registry** (`engine/metrics/registry.py`)
- **Signal inventory auto-extraction** from CSV/XLSX/XML (`tools/build_signal_inventory.py`)
- **Metric ontology graph export** (`tools/build_metric_graph.py`)
- **Streamlit app** (`apps/recruitments`) to browse inventory and explain actions.

## Quick start

```bash
pip install -r requirements.txt

# build inventory from a data directory
python tools/build_signal_inventory.py --data_dir /mnt/data --out canon/signals/auto_inventory.yaml

# build metric graph from canon specs
python tools/build_metric_graph.py --canon_metrics_dir canon/metrics/spec

# run Streamlit
streamlit run apps/recruitments/Home.py
```

## Extend
- Add new metric spec: `canon/metrics/spec/<metric>.v<maj>.yaml`
- Add compute function: `engine/metrics_impl/<metric>.py`
- Link via `impl.module` + `impl.function` in spec

## Notes
- The included xG/xT/PPDA implementations are MVP baselines.
- For production, use provider-specific action mapping and fitted models.
